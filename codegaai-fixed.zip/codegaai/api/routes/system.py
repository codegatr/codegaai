"""Sistem bilgisi ve sağlık kontrol uç noktaları."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from codegaai import __version__, __phase__
from codegaai.config import get_config
from codegaai.utils.logger import get_logger
from codegaai.utils.system_check import run_all_checks

router = APIRouter()
log = get_logger(__name__)


@router.get("/info")
async def info() -> dict[str, Any]:
    cfg = get_config()
    return {
        "name": "CODEGA AI",
        "version": __version__,
        "phase": __phase__,
        "language": cfg["app"]["language"],
        "theme": cfg["app"]["theme"],
        "models": cfg["models"],
    }


@router.get("/health")
async def health() -> dict:
    from codegaai.core.engine import LLMEngine
    from codegaai.core.self_healing import SelfHealing
    engine = LLMEngine.get()
    sh = SelfHealing.get()
    if not engine.is_ready:
        sh.report_error("llm", "health check: model yüklü değil")
    return {
        "ok": engine.is_ready,
        "engine": engine.status,
        "repairing": sh.is_repairing,
    }


@router.get("/check")
async def check() -> dict[str, Any]:
    import asyncio
    loop = asyncio.get_event_loop()
    try:
        report = await asyncio.wait_for(
            loop.run_in_executor(None, run_all_checks),
            timeout=5.0,
        )
        return {
            "overall": report.overall_status,
            "results": [
                {
                    "name": r.name, "status": r.status,
                    "message": r.message, "detail": r.detail,
                }
                for r in report.results
            ],
        }
    except asyncio.TimeoutError:
        return {
            "overall": "warning",
            "results": [{"name": "Donanım", "status": "warning",
                         "message": "Kontrol zaman aşımına uğradı", "detail": ""}],
        }


@router.get("/engines")
async def engines() -> dict[str, Any]:
    """Tüm motorların gerçek durumu — her biri 2 sn timeout."""
    import asyncio

    loop = asyncio.get_event_loop()

    def _collect() -> dict:
        from codegaai.core.engine import LLMEngine
        from codegaai.core.embeddings import EmbeddingService

        llm = LLMEngine.get()
        emb = EmbeddingService.get()

        chromadb_ok = False
        try:
            import chromadb  # type: ignore
            chromadb_ok = True
        except ImportError:
            pass

        img_status: dict = {"state": "unloaded", "ready": False}
        try:
            from codegaai.core.image_engine import ImageEngine
            img_status = ImageEngine.get().status
        except Exception:
            pass

        tts_status: dict = {"state": "unloaded", "ready": False}
        asr_status: dict = {"state": "unloaded", "ready": False}
        try:
            from codegaai.core.audio_engine import TTSEngine, ASREngine
            tts_status = TTSEngine.get().status
            asr_status = ASREngine.get().status
        except Exception:
            pass

        video_status: dict = {"state": "unloaded", "ready": False}
        try:
            from codegaai.core.video_engine import VideoEngine
            video_status = VideoEngine.get().status
        except Exception:
            pass

        learning_active = False
        feedback_count = 0
        deps_ok = False
        try:
            from codegaai.core.learning import FeedbackStore, TrainingEngine
            feedback_count = FeedbackStore.open().stats().get("total", 0)
            learning_active = TrainingEngine.get().is_training
            # check_dependencies frozen build'de pyarrow crash yaratır — lazy kontrol
            import sys
            deps_ok = not getattr(sys, "frozen", False)  # frozen değilse OK say
        except Exception:
            pass

        updater_status: dict = {"frozen_mode": False, "state": "idle"}
        try:
            from codegaai.core.updater import Updater
            upd = Updater.get()
            updater_status = {
                "frozen_mode": upd.is_frozen(),
                "state": upd.status.get("state", "idle"),
            }
        except Exception:
            pass

        llm_st = llm.status
        emb_st = emb.status

        return {
            "llm": {
                "active": llm.is_ready,
                "state": llm_st["state"],
                "model_id": llm_st.get("model_id"),
                "backend": llm_st.get("backend"),
                "error": llm_st.get("error"),
                "context_length": llm_st.get("context_length"),
                "phase": "Faz 3",
            },
            "embedding": {
                "active": emb.is_ready,
                "state": emb_st["state"],
                "model_id": emb_st.get("model_id"),
                "phase": "Faz 3",
            },
            "memory": {
                "active": chromadb_ok,
                "state": "ready" if chromadb_ok else "unloaded",
                "reason": ("ChromaDB hazır" if chromadb_ok
                           else "ChromaDB yüklü değil"),
                "phase": "Faz 3",
            },
            "image": {
                "active": img_status.get("ready", False),
                "state": img_status.get("state", "unloaded"),
                "model_id": img_status.get("model_id"),
                "phase": "Faz 4",
            },
            "audio": {
                "active": tts_status.get("ready", False) or asr_status.get("ready", False),
                "tts": tts_status,
                "asr": asr_status,
                "phase": "Faz 5",
            },
            "video": {
                "active": video_status.get("ready", False),
                "state": video_status.get("state", "unloaded"),
                "model_id": video_status.get("model_id"),
                "phase": "Faz 6",
            },
            "learning": {
                "active": learning_active or feedback_count > 0,
                "state": "training" if learning_active else "idle",
                "feedback_count": feedback_count,
                "training_deps_ok": deps_ok,
                "phase": "Faz 7",
            },
            "updater": {
                "active": updater_status.get("frozen_mode", False),
                "state": updater_status.get("state", "idle"),
                "frozen_mode": updater_status.get("frozen_mode", False),
                "phase": "Faz 8",
            },
        }

    try:
        result = await asyncio.wait_for(
            loop.run_in_executor(None, _collect),
            timeout=8.0,   # 4 → 8 saniye (GitHub Actions daha yavaş)
        )
        return result
    except asyncio.TimeoutError:
        log.warning("/engines timeout — kısmi yanıt döndürülüyor")
        # Timeout'ta da tüm key'leri döndür (test'ler için kritik)
        from codegaai.core.engine import LLMEngine
        llm = LLMEngine.get()
        _empty = {"active": False, "state": "unloaded", "phase": "?"}
        return {
            "llm": {
                "active": llm.is_ready,
                "state": llm.status["state"],
                "model_id": llm.status.get("model_id"),
                "error": llm.status.get("error"),
                "phase": "Faz 3",
            },
            "embedding": {**_empty, "phase": "Faz 3"},
            "memory":    {**_empty, "phase": "Faz 3"},
            "image":     {**_empty, "phase": "Faz 4"},
            "audio":     {**_empty, "phase": "Faz 5"},
            "video":     {**_empty, "phase": "Faz 6"},
            "learning":  {**_empty, "phase": "Faz 7"},
            "updater":   {**_empty, "phase": "Faz 8"},
            "_timeout": True,
        }


@router.get("/logs")
async def logs(limit: int = 80) -> dict[str, Any]:
    """Son uygulama loglarını UI'da göstermek için döndür."""
    from codegaai.config import LOGS_DIR, get_config

    log_cfg = get_config().get("logging", {})
    log_name = str(log_cfg.get("file", "codegaai.log")).split("/")[-1].split("\\")[-1]
    path = LOGS_DIR / log_name
    if not path.exists():
        return {"path": str(path), "lines": [], "exists": False}

    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        return {
            "path": str(path),
            "lines": lines[-max(1, min(limit, 300)):],
            "exists": True,
        }
    except Exception as exc:
        return {"path": str(path), "lines": [f"Log okunamadı: {exc}"], "exists": True}


# ============================================================
# Disk ve Model Dizini Yönetimi
# ============================================================

@router.get("/disks")
async def list_disks() -> dict:
    """
    Kullanılabilir diskler + boş alan.
    Her disk için max 1.5 sn timeout — CD/ağ/floppy takılmasın.
    """
    import asyncio
    import shutil
    from codegaai.config import MODELS_DIR, DATA_DIR

    async def _safe_disk_usage(path: str) -> tuple | None:
        """Disk kullanımını 1.5 sn timeout ile al."""
        loop = asyncio.get_event_loop()
        try:
            result = await asyncio.wait_for(
                loop.run_in_executor(None, shutil.disk_usage, path),
                timeout=1.5,
            )
            return result
        except Exception:
            return None

    disks = []

    if __import__("sys").platform == "win32":
        try:
            import ctypes
            # GetLogicalDrives → bitmask
            bitmask = ctypes.windll.kernel32.GetLogicalDrives()
            for i, letter in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
                if not (bitmask >> i & 1):
                    continue

                path = f"{letter}:\\"

                # GetDriveType: 3=FIXED, 2=REMOVABLE — CD/network/unknown atla
                drive_type = ctypes.windll.kernel32.GetDriveTypeW(path)
                if drive_type not in (2, 3):   # 2=removable, 3=fixed
                    continue

                usage = await _safe_disk_usage(path)
                if usage is None:
                    continue

                total, used, free = usage
                if total == 0:
                    continue

                disks.append({
                    "path": path,
                    "label": letter,
                    "type": "fixed" if drive_type == 3 else "removable",
                    "total_gb": round(total / 1e9, 1),
                    "free_gb": round(free / 1e9, 1),
                    "used_pct": round(used / total * 100),
                })
        except Exception as exc:
            log.warning("Windows disk listesi hatası: %s", exc)
    else:
        for mount in ["/", str(__import__("pathlib").Path.home())]:
            usage = await _safe_disk_usage(mount)
            if usage:
                total, used, free = usage
                disks.append({
                    "path": mount,
                    "label": mount,
                    "type": "fixed",
                    "total_gb": round(total / 1e9, 1),
                    "free_gb": round(free / 1e9, 1),
                    "used_pct": round(used / total * 100),
                })

    return {
        "disks": disks,
        "current_models_dir": str(MODELS_DIR),
        "current_data_dir": str(DATA_DIR),
    }


@router.post("/models-dir")
async def set_models_dir(body: dict) -> dict:
    """Model indirme dizinini değiştir — anında etkin olur."""
    import json
    from codegaai.config import DATA_DIR

    new_path = body.get("path", "").strip()
    if not new_path:
        return {"error": "path boş olamaz"}

    from pathlib import Path
    try:
        p = Path(new_path).expanduser().resolve()
        p.mkdir(parents=True, exist_ok=True)
        (p / "llm").mkdir(exist_ok=True)
        (p / "embedding").mkdir(exist_ok=True)
    except Exception as exc:
        return {"error": f"Dizin oluşturulamadı: {exc}"}

    # Config dosyasına yaz
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    cfg_file = DATA_DIR / "codegaai_config.json"
    cfg = {}
    if cfg_file.exists():
        try:
            cfg = json.loads(cfg_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    cfg["models_dir"] = str(p)
    cfg_file.write_text(json.dumps(cfg, ensure_ascii=False, indent=2),
                        encoding="utf-8")

    # ModelRegistry singleton'ını sıfırla → yeni dizini görsün
    try:
        from codegaai.core.models_registry import ModelRegistry
        ModelRegistry._instance = None
        log.info("ModelRegistry sıfırlandı: yeni models_dir=%s", p)
    except Exception as exc:
        log.warning("Registry sıfırlama hatası: %s", exc)

    return {
        "ok": True,
        "new_path": str(p),
        "message": "Model dizini güncellendi. Bir sonraki indirme buraya gidecek.",
        "restart_needed": False,
    }


@router.get("/models-dir")
async def get_models_dir() -> dict:
    from codegaai.config import MODELS_DIR
    import shutil
    try:
        total, used, free = shutil.disk_usage(str(MODELS_DIR.anchor))
        disk_free_gb = round(free / 1e9, 1)
    except Exception:
        disk_free_gb = 0

    # Mevcut model boyutları
    model_size_gb = 0.0
    try:
        model_size_gb = sum(
            f.stat().st_size for f in MODELS_DIR.rglob("*") if f.is_file()
        ) / 1e9
    except Exception:
        pass

    return {
        "models_dir": str(MODELS_DIR),
        "model_size_gb": round(model_size_gb, 2),
        "disk_free_gb": disk_free_gb,
    }


# ── HuggingFace Token ──────────────────────────────────────────────────────

@router.post("/hf-token")
async def save_hf_token(body: dict) -> dict:
    """HuggingFace token'ı config.json'a kaydet."""
    import json
    from codegaai.config import DATA_DIR

    token = body.get("token", "").strip()

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    cfg_file = DATA_DIR / "codegaai_config.json"
    cfg = {}
    if cfg_file.exists():
        try:
            cfg = json.loads(cfg_file.read_text(encoding="utf-8"))
        except Exception:
            pass

    if token:
        cfg["hf_token"] = token
        import os
        os.environ["HF_TOKEN"] = token
        log.info("HuggingFace token kaydedildi")
    else:
        cfg.pop("hf_token", None)
        import os
        os.environ.pop("HF_TOKEN", None)
        log.info("HuggingFace token silindi")

    cfg_file.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "has_token": bool(token)}


@router.get("/hf-token")
async def get_hf_token_status() -> dict:
    """HF token var mı?"""
    from codegaai.core.models_registry import _get_hf_token
    tok = _get_hf_token()
    return {
        "has_token": bool(tok),
        "preview": (tok[:8] + "..." + tok[-4:]) if len(tok) > 12 else ("***" if tok else ""),
    }
