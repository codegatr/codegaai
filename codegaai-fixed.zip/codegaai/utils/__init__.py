"""codegaai.utils - Yardımcı modüller."""
