import assert from "node:assert";
import os from "node:os";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const mainDir = path.join(here, "..", "src", "main");
const joinPath = path.join.bind(path);
path.join = (...parts) => {
  const joined = joinPath(...parts);
  return parts[0] === mainDir && joined.endsWith(".js") ? pathToFileURL(joined).href : joined;
};

// Bellek testleri kullanıcı dosyasına dokunmasın: geçici yola yönlendir
const tmpMem = path.join(os.tmpdir(), `codega-mem-${Date.now()}.json`);
process.env.CODEGA_MEMORY_PATH = tmpMem;

const { runReact, cleanFinal } = await import(path.join(mainDir, "agent", "agent-loop.js"));
const toolsMod = await import(path.join(mainDir, "agent", "tools.js"));
const memMod = await import(path.join(mainDir, "agent", "memory.js"));

const tools = toolsMod.default || toolsMod;
const memory = memMod.default || memMod;

let passed = 0;
function ok(name) { console.log(`  ✓ ${name}`); passed += 1; }

// 1) Döngü gözlemi modele GERİ besliyor ve sentezliyor
{
  const seen = [];
  const fakeLLM = async (messages) => {
    seen.push(messages.map((m) => ({ role: m.role, content: m.content })));
    return seen.length === 1
      ? 'Hesaplıyorum. <tool>calculate("21*2")</tool>'
      : "İşlemin sonucu 42.";
  };
  const res = await runReact(
    [{ role: "user", content: "21 çarpı 2?" }],
    fakeLLM,
    { maxIters: 4 }
  );
  assert.strictEqual(res.iterations, 2, "iki tur olmalı");
  assert.strictEqual(res.stoppedReason, "final_answer");
  assert.strictEqual(res.content, "İşlemin sonucu 42.");
  assert.strictEqual(res.toolCalls.length, 1);
  assert.strictEqual(res.toolCalls[0].name, "calculate");
  assert.ok(String(res.toolCalls[0].result).includes("42"), "araç 42 üretmeli");
  // KRİTİK: 2. turda model gözlemi (42) görmüş olmalı
  const turn2 = seen[1].map((m) => m.content).join("\n");
  assert.ok(turn2.includes("Araç Sonuçları (Gözlem)"), "gözlem geri beslenmeli");
  assert.ok(turn2.includes("42"), "gözlemde 42 olmalı");
  ok("ReAct: gözlem geri besleniyor + sentez");
}

// 2) max_iters'e uyuyor
{
  let n = 0;
  const alwaysTool = async (messages) => {
    n += 1;
    const last = messages[messages.length - 1].content;
    if (last.includes("ARAÇ KULLANMA")) return "Toplanan bilgiyle final.";
    return 'Devam. <tool>calculate("1+1")</tool>';
  };
  const res = await runReact([{ role: "user", content: "x" }], alwaysTool, { maxIters: 3 });
  assert.strictEqual(res.stoppedReason, "max_iters");
  assert.strictEqual(res.iterations, 3);
  assert.strictEqual(res.content, "Toplanan bilgiyle final.");
  assert.strictEqual(n, 4, "3 döngü + 1 sentez = 4 üretim");
  ok("ReAct: max_iters koruması + sentez");
}

// 3) Araç gerekmeyen soru tek turda biter, <think> temizlenir
{
  const direct = async () => "<think>basit selam</think>Merhaba Yunus!";
  const res = await runReact([{ role: "user", content: "selam" }], direct, { maxIters: 4 });
  assert.strictEqual(res.iterations, 1);
  assert.strictEqual(res.stoppedReason, "final_answer");
  assert.strictEqual(res.toolCalls.length, 0);
  assert.strictEqual(res.content, "Merhaba Yunus!", "<think> gizlenmeli");
  ok("ReAct: düz cevap + <think> gizleme");
}

// 4) generateFn hatası güvenle yakalanıyor
{
  const boom = async () => { throw new Error("ollama yok"); };
  const res = await runReact([{ role: "user", content: "x" }], boom, { maxIters: 4 });
  assert.strictEqual(res.stoppedReason, "error");
  assert.ok(res.content.includes("ollama yok"));
  ok("ReAct: üretim hatası güvenli");
}

// 5) Araçlar (offline): calculate + current_time
{
  assert.ok(tools.toolCalculate('"21*2"' ? "21*2" : "").includes("42"));
  assert.ok(tools.toolCalculate("sqrt(144) + 5^2").includes("37"));
  assert.ok(/Türkiye/.test(tools.toolCurrentTime()));
  ok("Araçlar: calculate + current_time");
}

// 6) Kalıcı hafıza: remember + recall (geçici dosyada)
{
  memory.remember("Yunus Konya'da yaşıyor, web geliştirici");
  memory.remember("Yunus elektrikli araç aldı");
  const hits = memory.recall("Yunus nerede yaşıyor");
  assert.ok(hits.some((h) => h.includes("Konya")), "Konya hatırlanmalı");
  ok("Hafıza: remember + recall");
  fs.rmSync(tmpMem, { force: true });
}

// 7) parseAndRunTools gerçekten çalıştırıyor (calculate, offline)
{
  const { calls } = await tools.parseAndRunTools(
    'Bak: <tool>calculate("100/4")</tool> tamam.'
  );
  assert.strictEqual(calls.length, 1);
  assert.strictEqual(calls[0].name, "calculate");
  assert.ok(String(calls[0].result).includes("25"));
  ok("parseAndRunTools: gerçek çalıştırma");
}

// 8) parseSearchResults: statik HTML üzerinde (internetsiz)
{
  const sampleHtml = `
    <a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fornek.com%2Fsayfa">Örnek Başlık</a>
    <a class="result__snippet">Bu bir örnek özet metnidir.</a>
    <a class="result__a" href="https://ikinci.com">İkinci Sonuç</a>
    <a class="result__snippet">İkinci özet.</a>`;
  const parsed = tools.parseSearchResults(sampleHtml, 5);
  assert.strictEqual(parsed.length, 2);
  assert.strictEqual(parsed[0].title, "Örnek Başlık");
  assert.strictEqual(parsed[0].href, "https://ornek.com/sayfa", "uddg çözülmeli");
  assert.ok(parsed[0].snippet.includes("örnek özet"));
  ok("Araştırma: arama sonucu parser (offline)");
}

// 9) research aracı kayıtlı ve loop'tan çağrılabilir
{
  assert.ok(tools.TOOLS.research, "research aracı kayıtlı olmalı");
  assert.ok(tools.TOOLS.web_search && tools.TOOLS.read_url, "web araçları kayıtlı");
  ok("Araştırma: research/web_search/read_url kayıtlı");
}

// 10) Toleranslı format: (tool), [tool], çıplak, iç içe parantez
{
  assert.strictEqual(tools.extractToolCalls("Bak (tool)current_time()").length, 1);
  assert.strictEqual(tools.extractToolCalls("Bak (tool)current_time()")[0].name, "current_time");
  assert.strictEqual(tools.extractToolCalls('[tool]calculate("12+3")').length, 1);
  assert.strictEqual(tools.extractToolCalls('sonuç: web_search("x")')[0].name, "web_search");
  // iç içe parantezli argüman bozulmamalı
  const nested = tools.extractToolCalls('<tool>calculate("(1+2)*3")</tool>');
  assert.strictEqual(nested[0].argsStr, '"(1+2)*3"');
  assert.ok(tools.toolCalculate("(1+2)*3").includes("9"));
  ok("Toleranslı format: (tool)/[tool]/çıplak/iç içe parantez");
}

// 11) Ekrandaki tam hata senaryosu: model "(tool)current_time()" yazıyor
{
  let n = 0;
  const fake = async (messages) => {
    n += 1;
    if (n === 1) return "Son durumu kontrol edelim. (tool)current_time()";
    return "Bugünkü tarih ve saat yukarıda.";
  };
  const res = await runReact([{ role: "user", content: "son durum?" }], fake, { maxIters: 3 });
  assert.strictEqual(res.iterations, 2, "(tool) formatı yakalanıp döngü dönmeli");
  assert.strictEqual(res.stoppedReason, "final_answer");
  assert.strictEqual(res.toolCalls.length, 1);
  assert.strictEqual(res.toolCalls[0].name, "current_time");
  assert.ok(!res.content.includes("(tool)"), "final cevapta (tool) kalıntısı olmamalı");
  ok("Loop: (tool)current_time() artık çalışıyor (ekran hatası çözüldü)");
}

// 12) stripToolCalls final cevabı temizliyor
{
  assert.strictEqual(tools.stripToolCalls("Cevap. (tool)current_time()"), "Cevap.");
  assert.strictEqual(tools.stripToolCalls('<tool>weather("Konya")</tool>'), "");
  ok("stripToolCalls: kalıntı temizleme");
}

// 13) Ayar deposu (geçici dosyada)
{
  const tmpSettings = path.join(os.tmpdir(), `codega-set-${Date.now()}.json`);
  process.env.CODEGA_SETTINGS_PATH = tmpSettings;
  const settingsMod = await import(path.join(mainDir, "agent", "settings-store.js"));
  const settings = settingsMod.default || settingsMod;
  const def = settings.getSettings();
  assert.strictEqual(def.autonomousLearning, true, "varsayılan açık");
  const next = settings.setSettings({ autonomousLearning: false });
  assert.strictEqual(next.autonomousLearning, false);
  assert.strictEqual(settings.getSettings().autonomousLearning, false, "kalıcı");
  fs.rmSync(tmpSettings, { force: true });
  ok("Ayar deposu: get/set/kalıcılık");
}

// 14) Otonom öğrenme: çıkarım + recall + temizleme
{
  const tmpMem2 = path.join(os.tmpdir(), `codega-mem2-${Date.now()}.json`);
  process.env.CODEGA_MEMORY_PATH = tmpMem2;
  const facts = memory.extractDurableFacts("Merhaba, benim adım Yunus ve Konya'da yaşıyorum.");
  assert.ok(facts.some((f) => f.includes("Yunus")), "ad çıkarılmalı");
  assert.ok(facts.some((f) => f.includes("Konya")), "şehir çıkarılmalı");
  for (const f of facts) memory.remember(f);
  assert.ok(memory.listFacts().length >= 2, "öğrenilenler listelenmeli");
  assert.ok(memory.recall("nerede yaşıyor").some((h) => h.includes("Konya")));
  memory.clearAll();
  assert.strictEqual(memory.listFacts().length, 0, "temizlenmeli");
  fs.rmSync(tmpMem2, { force: true });
  ok("Otonom öğrenme: çıkarım + recall + temizleme");
}

// 15) System prompt hafızayı enjekte ediyor + insansı üslup
{
  const spMod = await import(path.join(mainDir, "agent", "system-prompt.js"));
  const sp = spMod.default || spMod;
  const withMem = sp.buildSystemPrompt("chat", {
    memory: ["Kullanıcının adı Yunus", "Kullanıcı Konya şehrinde yaşıyor"],
    humanTone: true,
  });
  assert.ok(withMem.includes("hatırladıkların"), "hafıza başlığı olmalı");
  assert.ok(withMem.includes("Yunus"), "hafıza içeriği enjekte edilmeli");
  assert.ok(withMem.includes("İnsansı ol"), "insansı üslup talimatı olmalı");
  const noMem = sp.buildSystemPrompt("chat", { memory: [], humanTone: false });
  assert.ok(!noMem.includes("hatırladıkların"), "hafıza yoksa başlık olmamalı");
  ok("System prompt: hafıza enjeksiyonu + insansı üslup");
}

// 16) GitHub araçları kayıtlı + token yokken zarif davranış (offline)
{
  const tmpSet = path.join(os.tmpdir(), `codega-set-gh-${Date.now()}.json`);
  process.env.CODEGA_SETTINGS_PATH = tmpSet;
  delete process.env.CODEGA_GH_TOKEN;
  assert.ok(tools.TOOLS.github_read && tools.TOOLS.github_list, "github_read/list kayıtlı");
  assert.ok(tools.TOOLS.github_search && tools.TOOLS.github_dispatch, "search/dispatch kayıtlı");
  const { calls } = await tools.parseAndRunTools('<tool>github_read("owner/repo/dosya.txt")</tool>');
  assert.strictEqual(calls.length, 1);
  assert.strictEqual(calls[0].name, "github_read");
  assert.ok(/token/i.test(String(calls[0].result)), "token yokken uyarı dönmeli, patlamamalı");
  fs.rmSync(tmpSet, { force: true });
  ok("GitHub araçları: kayıt + token yokken zarif");
}

// 17) knowledge.parseFactText: JSONL ve düz satır
{
  const kMod = await import(path.join(mainDir, "agent", "knowledge.js"));
  const knowledge = kMod.default || kMod;
  assert.strictEqual(knowledge.parseFactText('{"text":"Konya","at":1}'), "Konya");
  assert.strictEqual(knowledge.parseFactText("düz satır"), "düz satır");
  assert.strictEqual(typeof knowledge.isConfigured(), "boolean");
  ok("Knowledge: JSONL/düz satır ayrıştırma");
}

// 18) RAG: saf fonksiyonlar + keyword fallback (Ollama'sız, offline)
{
  const tmpRag = path.join(os.tmpdir(), `codega-rag-${Date.now()}.json`);
  process.env.CODEGA_RAG_PATH = tmpRag;
  const ragMod = await import(path.join(mainDir, "agent", "rag.js"));
  const rag = ragMod.default || ragMod;

  assert.ok(Math.abs(rag.cosineSimilarity([1, 0], [1, 0]) - 1) < 1e-9, "aynı vektör = 1");
  assert.ok(Math.abs(rag.cosineSimilarity([1, 0], [0, 1])) < 1e-9, "dik vektör = 0");
  assert.strictEqual(rag.chunkText("kısa metin").length, 1);
  assert.ok(rag.chunkText("x".repeat(2000)).length >= 2, "uzun metin parçalanmalı");
  assert.ok(rag.keywordScore("konya nüfus", "Konya nüfusu çoktur") > 0);

  // Ollama kapalı -> embedding null -> keyword fallback
  const add = await rag.addDocument("Proje Notu", "CODEGA B2B portalı bayi.lemondedutacos.com adresinde çalışır.");
  assert.ok(add.ok && add.added >= 1, "doküman eklendi");
  const hits = await rag.search("bayi portalı adresi", 4);
  assert.ok(hits.length >= 1 && /lemondedutacos/.test(hits[0].text), "keyword fallback ile bulundu");
  const st = rag.stats();
  assert.ok(st.chunks >= 1 && st.documents >= 1);
  rag.clearAll();
  assert.strictEqual(rag.stats().chunks, 0);
  fs.rmSync(tmpRag, { force: true });
  ok("RAG: cosine/chunk/keyword + ekle/ara/temizle (offline)");
}

// 19) rag_search aracı kayıtlı
{
  assert.ok(tools.TOOLS.rag_search, "rag_search aracı kayıtlı");
  ok("RAG: rag_search aracı kayıtlı");
}

// 20) Öz değerlendirme: OK -> değişmez, düzeltme -> revize
{
  const rfMod = await import(path.join(mainDir, "agent", "reflect.js"));
  const reflect = rfMod.default || rfMod;
  assert.strictEqual(reflect.looksOk("OK"), true);
  assert.strictEqual(reflect.looksOk("Tamam, doğru."), true);
  assert.strictEqual(reflect.looksOk("SADECE AYNEN"), true);
  assert.strictEqual(reflect.looksOk("Hayır, yanlış: ..."), false);

  const okRes = await reflect.reflect("2+2?", "4", async () => "OK");
  assert.strictEqual(okRes.revised, false);
  assert.strictEqual(okRes.answer, "4");
  const aynenLeak = await reflect.reflect("Cevapların hepsini verecek misin?", "Evet, hepsini vereceğim.", async () => "SADECE AYNEN");
  assert.strictEqual(aynenLeak.answer, "Evet, hepsini vereceğim.", "kontrol tokenı kullanıcıya sızmamalı");

  const fixRes = await reflect.reflect("Konya nüfusu?", "185.000", async () => "Konya nüfusu yaklaşık 2,3 milyondur.");
  assert.strictEqual(fixRes.revised, true);
  assert.ok(/2,3 milyon/.test(fixRes.answer));

  // denetim patlarsa taslak korunur
  const safe = await reflect.reflect("x", "taslak", async () => { throw new Error("yok"); });
  assert.strictEqual(safe.answer, "taslak");

  // SIZINTI: etiketli denetçi raporu cevaba sızmamalı
  const leak = await reflect.reflect(
    "günaydin",
    "İyi günler. Size nasıl yardımcı olabilirim?",
    async () =>
      "İyi günler. Size nasıl yardımcı olabilirim?\n\nDÜZELTİLMİŞ CEVAP:\nGünaydın! Size nasıl yardımcı olabilirim?\n\nUydu: None detected\nEksiklik: None detected\nSorun: yok"
  );
  assert.ok(/Günaydın/.test(leak.answer), "temiz düzeltme çıkarılmalı");
  assert.ok(!/DÜZELTİLMİŞ|Uydu:|None detected|Sorun:/.test(leak.answer), "rapor SIZMAMALI");

  // Sadece rapor (kullanılabilir cevap yok) -> taslağa dön
  const onlyReport = await reflect.reflect(
    "selam",
    "Merhaba!",
    async () => "Uydu: None detected\nEksiklik: yok\nSorun: yok"
  );
  assert.strictEqual(onlyReport.answer, "Merhaba!", "rapor-only -> taslak");
  ok("Öz değerlendirme: OK/düzeltme/hata-güvenli + rapor sızıntısı engellendi");
}

// 20b) Benchmark reasoner: cevaplanabilir testlerde eksik/refusal cevabı onar
{
  const bmMod = await import(path.join(mainDir, "agent", "benchmark-reasoner.js"));
  const benchmark = bmMod.default || bmMod;
  const prompt = [
    "TEST H — Probability",
    "Bir kutuda: 5 kırmızı 5 mavi 5 yeşil top var. Işıklar kapalı.",
    "En az kaç top çekersen kesin olarak aynı renkten 2 top çekmiş olursun?",
    "",
    "TEST J — Final Boss",
    "Bir gölette nilüferler her gün iki katına çıkıyor. Göl 60. gün tamamen doluyor.",
    "Yarısı hangi gün? Çeyreği hangi gün? Sekizde biri hangi gün?",
  ].join("\n");
  assert.deepStrictEqual(benchmark.missingLabels(prompt, "TEST H: 4"), ["J"]);
  const repaired = benchmark.repairBenchmarkAnswer(
    prompt,
    "Test H and Test J cannot be definitively answered based on the provided information."
  );
  assert.strictEqual(repaired.repaired, true);
  assert.match(repaired.answer, /Test 1:.*4/);
  assert.match(repaired.answer, /Test 2:.*59.*58.*57/);
  assert.doesNotMatch(repaired.answer, /\bTEST\s+[A-Z]:/);
  const instant = benchmark.solveKnownReasoningBenchmarks(prompt);
  assert.match(instant, /Test 1:.*4/);
  assert.match(instant, /Test 2:.*59.*58.*57/);
  assert.doesNotMatch(instant, /\bTEST\s+[A-Z]:/);
  ok("Benchmark reasoner: cevaplanabilir refusal/eksik yanıt onarılır");
}

// 21) Görev planlayıcı: parse + looksLikeGoal + makePlan
{
  const plMod = await import(path.join(mainDir, "agent", "planner.js"));
  const planner = plMod.default || plMod;
  const steps = planner.parsePlan("1. Repoyu klonla\n2. Bağımlılıkları kur\n3. Testleri çalıştır");
  assert.strictEqual(steps.length, 3);
  assert.strictEqual(steps[0], "Repoyu klonla");
  assert.strictEqual(planner.parsePlan("- adım bir\n* adım iki").length, 2);
  assert.strictEqual(planner.looksLikeGoal("selam"), false);
  assert.strictEqual(
    planner.looksLikeGoal("php ile bir blog sitesi oluştur ve sonra veritabanına bağla"),
    true
  );
  const plan = await planner.makePlan("X yap", async () => "1. ilk\n2. ikinci");
  assert.ok(plan.length === 2 && plan[0] === "ilk");
  const safe = await planner.makePlan("X", async () => { throw new Error("yok"); });
  assert.deepStrictEqual(safe, []);
  ok("Görev planlayıcı: parse/looksLikeGoal/makePlan");
}

// 22) Çoklu ajan: yönlendirme + tool policy + orchestrate (fake'lerle, offline)
{
  const agMod = await import(path.join(mainDir, "agent", "agents.js"));
  const agents = agMod.default || agMod;
  assert.strictEqual(agents.routeStep("PHP fonksiyonu yaz ve repo'ya bak"), "coder");
  assert.strictEqual(agents.routeStep("güncel fiyatları araştır"), "researcher");
  assert.strictEqual(agents.routeStep("çıktıyı kontrol et ve doğrula"), "reviewer");
  assert.ok(agents.buildSpecialistPrompt("coder").includes("github_read"));

  // tool policy: izinsiz araç çalıştırılmamalı
  const { calls } = await tools.parseAndRunTools(
    '<tool>calculate("2+2")</tool>',
    ["web_search"] // calculate izinli değil
  );
  assert.strictEqual(calls[0].error, "not_allowed");

  // orchestrator: fake ctx ile akış
  const orMod = await import(path.join(mainDir, "agent", "orchestrator.js"));
  const orchestrator = orMod.default || orMod;
  const res = await orchestrator.runOrchestrated("bir blog sitesi yap", {
    makePlan: async () => ["tasarımı araştır", "kodu yaz", "kontrol et"],
    routeStep: agents.routeStep,
    runSpecialist: async (key, step) => `${key}:${step} tamam`,
    synthesize: async (g, steps) => `FINAL(${steps.length} adım)`,
  });
  assert.strictEqual(res.stepResults.length, 3);
  assert.ok(res.content.startsWith("FINAL(3"));
  ok("Çoklu ajan: routing + tool policy + orchestrate");
}

// 23) Basit sohbet tespiti (selam yolu araç/ReAct'a girmesin)
{
  const mm = await import(path.join(mainDir, "model-manager.js"));
  const isST = (mm.default || mm).isSmallTalk;
  for (const g of ["günaydın", "Günaydin", "selam", "merhaba", "teşekkürler", "naber"]) {
    assert.strictEqual(isST(g), true, `smalltalk olmalı: ${g}`);
  }
  for (const q of ["günaydın, bana bir PHP fonksiyonu yaz", "Konya nüfusu nedir?", "şu repodaki hatayı bul"]) {
    assert.strictEqual(isST(q), false, `smalltalk OLMAMALI: ${q}`);
  }
  ok("Basit sohbet tespiti: selam evet, görev/soru hayır");
}

// 23b) Eksik kod modeli: kullanıcıyı ayarlara göndermek yerine otomatik hazırlama mesajı
{
  const mm = await import(path.join(mainDir, "model-manager.js"));
  const M = mm.default || mm;
  const text = M.missingModelReply("code", "qwen2.5-coder:3b-instruct", true);
  assert.ok(/arka planda hazırlamaya başladım/.test(text), "otomatik hazırlama söylenir");
  assert.ok(/Ayarlar'a gitmene gerek yok/.test(text), "kullanıcı ayarlara itilmez");
  assert.ok(/PHP/.test(text), "PHP/kod niyeti korunur");
  ok("Eksik kod modeli: otomatik hazırlama mesajı");
}

// 23c) Model indirme ilerlemesi: yüzde + indirilen/toplam + hız ayrıştırılır
{
  const mm = await import(path.join(mainDir, "model-manager.js"));
  const M = mm.default || mm;
  const p = M.parsePullProgress("pulling manifest 47% ▕████░░░░▏ 2.44 GB/5.20 GB 12 MB/s");
  assert.strictEqual(Math.round(p.percent), 47, "yüzde okunur");
  assert.ok(p.downloadedBytes > 2.4 * 1024 * 1024 * 1024, "indirilen GB okunur");
  assert.ok(p.totalBytes > 5 * 1024 * 1024 * 1024, "toplam GB okunur");
  assert.ok(p.speedBytesPerSec >= 12 * 1024 * 1024, "hız okunur");
  ok("Model indirme ilerlemesi: yüzde/MB/hız ayrıştırma");
}

// 23d) Rehberli model indirme: sistem popup'ı progress panelini örtmez
{
  const mainText = fs.readFileSync(joinPath(mainDir, "main.js"), "utf8");
  const modelSetupBlock = mainText.slice(mainText.indexOf('ipcMain.handle("model:setup"'), mainText.indexOf('ipcMain.handle("model:prepare"'));
  assert.ok(!/title:\s*"Model İndir"/.test(modelSetupBlock), "model indirme için native popup yok");
  assert.ok(/prepareModel\(modelId/.test(modelSetupBlock), "model setup doğrudan prepareModel çağırır");
  assert.ok(/setSettings\(\{\s*defaultModel:\s*status\.model\s*\}\)/s.test(modelSetupBlock), "kurulan model varsayılan yapılır");
  assert.ok(/modelManager\.detect\(\)/.test(modelSetupBlock), "varsayılan model sonrası durum yeniden algılanır");
  assert.ok(/isDestroyed\(\)/.test(modelSetupBlock), "destroy edilmiş renderer'a status gönderilmez");
  ok("Rehberli model indirme: progress panelini örten popup yok");
}

// 23e) Model algılama: kurulu önerilen model, kullanıcı varsayılanını ezmemeli
{
  const managerText = fs.readFileSync(joinPath(mainDir, "model-manager.js"), "utf8");
  const detectBlock = managerText.slice(managerText.indexOf("  async detect()"), managerText.indexOf("  async getModels()"));
  assert.ok(/settings\.defaultModel\s*\|\|\s*settings\.model/.test(detectBlock), "detect kullanıcı varsayılanını okur");
  assert.ok(/configuredInstalled\s*\|\|\s*modelCandidates\(\)/.test(detectBlock), "kurulu varsayılan model aday listesinden önce gelir");
  assert.ok(/isInstalledModel\(installed,\s*configuredModel\)/.test(detectBlock), "varsayılan model kuruluysa aktif sayılır");
  ok("Model algılama: varsayılan model aktif durumunu korur");
}

// 24) Kendi kendine bakım: sağlık + bozuk depo onarımı (fake'lerle, diske dokunmadan)
{
  const smMod = await import(path.join(mainDir, "agent", "self-maintenance.js"));
  const sm = smMod.default || smMod;
  let repaired = false;
  const report = await sm.runSelfCheck({
    ollamaReachable: async () => true,
    readJson: (p) => (p === "/bozuk" ? { state: "repaired", value: null } : { state: "ok", value: {} }),
    jsonFiles: [
      { name: "settings", path: "/iyi" },
      { name: "memory", path: "/bozuk", onRepair: () => { repaired = true; } },
    ],
    now: 123,
  });
  assert.strictEqual(report.items.find((i) => i.name === "ollama").status, "ok");
  assert.ok(report.repairs.includes("memory"), "bozuk depo onarıma alınmalı");
  assert.strictEqual(repaired, true, "onRepair çağrılmalı");
  assert.strictEqual(report.healthy, false, "onarım olduysa healthy=false");

  const clean = await sm.runSelfCheck({ ollamaReachable: async () => true, jsonFiles: [], readJson: () => ({ state: "ok" }) });
  assert.strictEqual(clean.healthy, true);
  ok("Kendi kendine bakım: sağlık denetimi + güvenli onarım");
}

// 25) Denetimli kendini geliştirme: öneri üret + PR aç (fake git, main'e DOKUNMAZ)
{
  const siMod = await import(path.join(mainDir, "agent", "self-improve.js"));
  const si = siMod.default || siMod;
  const p = si.buildProposal({ idea: "Önbellek süresini ayarlanabilir yap", version: "0.12.0" });
  assert.ok(p.slug && !/\s/.test(p.slug), "slug boşluksuz olmalı");
  assert.ok(/öneri/i.test(p.body) && /otomatik birleştirilmez/i.test(p.body), "öneri notu + güvenlik notu");

  const calls = [];
  const fakeGit = {
    splitRepo: (r) => { const [owner, repo] = r.split("/"); return { owner, repo }; },
    getRepoMeta: async () => { calls.push("meta"); return { default_branch: "main" }; },
    getBranchSha: async () => { calls.push("sha"); return "abc123"; },
    createBranch: async (o, r, b, sha) => { calls.push("branch:" + b); assert.notStrictEqual(b, "main"); return {}; },
    createFileOnBranch: async (o, r, fp, b) => { calls.push("file:" + fp); assert.notStrictEqual(b, "main"); return {}; },
    openPullRequest: async (o, r, head, base) => { calls.push("pr:" + head + "->" + base); return { html_url: "https://x/pr/1", number: 1 }; },
  };
  const res = await si.submitProposal(fakeGit, "codegatr/codegaai", p, 99);
  assert.strictEqual(res.number, 1);
  assert.ok(res.branch.startsWith("codega-oneri/"), "ayrı dal");
  assert.ok(calls.some((c) => c.startsWith("pr:") && c.endsWith("->main")), "PR tabanı main");
  assert.ok(!calls.some((c) => c === "file:main" || c === "branch:main"), "main'e yazılmamalı");
  ok("Denetimli geliştirme: öneri + ayrı dal + PR (main'e dokunmaz)");
}

// 26) Kendini gözlemleme: sinyalleri eşik aşınca öneri taslağına çevir (saf)
{
  const idMod = await import(path.join(mainDir, "agent", "improve-drafts.js"));
  const id = idMod.default || idMod;
  const drafts = id.buildDrafts({
    "tool_error:web_search": { kind: "tool_error", subject: "web_search", count: 5 },
    "tool_error:rare": { kind: "tool_error", subject: "rare", count: 1 },
    "store_repair:memory": { kind: "store_repair", subject: "memory", count: 1 },
  });
  assert.ok(drafts.some((d) => d.kind === "tool_error" && /web_search/.test(d.idea)), "sık hata önerisi");
  assert.ok(!drafts.some((d) => d.subject === "rare"), "eşik altı dahil edilmemeli");
  assert.ok(drafts.some((d) => d.kind === "store_repair"), "onarım eşiği 1");
  assert.strictEqual(drafts[0].count, 5, "en sık önce");
  ok("Kendini gözlemleme: sinyal → eşik → öneri taslağı");
}

// 27) Otonom öneri: işaretlenmemiş taslaklar (key + proposedAt mantığı, saf)
{
  const idMod = await import(path.join(mainDir, "agent", "improve-drafts.js"));
  const id = idMod.default || idMod;
  const drafts = id.buildDrafts({
    "tool_error:web_search": { kind: "tool_error", subject: "web_search", count: 5 },
    "ollama_down": { kind: "ollama_down", count: 4, proposedAt: 111 },
  });
  const byKey = Object.fromEntries(drafts.map((d) => [d.key, d]));
  assert.ok(byKey["tool_error:web_search"], "key üretilmeli");
  assert.strictEqual(byKey["tool_error:web_search"].proposedAt, null, "yeni taslak proposedAt=null");
  assert.strictEqual(byKey["ollama_down"].proposedAt, 111, "önerilmiş taslak işaretli kalır");
  ok("Otonom öneri: taslak key + proposedAt ayrımı");
}

// 28) Geri bildirim sinyali öneri taslağına dönüşür
{
  const idMod = await import(path.join(mainDir, "agent", "improve-drafts.js"));
  const id = idMod.default || idMod;
  const d = id.buildDrafts({ "negative_feedback": { kind: "negative_feedback", count: 3 } });
  assert.ok(d.some((x) => x.kind === "negative_feedback" && /olumsuz/i.test(x.idea)), "olumsuz geri bildirim önerisi");
  const fbMod = await import(path.join(mainDir, "agent", "feedback.js"));
  assert.ok((fbMod.default || fbMod).stats, "feedback.stats var");
  ok("Geri bildirim: 👎 eşiği -> öneri taslağı");
}

// 29) Sistem analizi: RAM'e göre güncel model önerisi (saf)
{
  const siMod = await import(path.join(mainDir, "agent", "system-info.js"));
  const si = siMod.default || siMod;
  const opts = [
    { id: "qwen3.5:0.8b", label: "Qwen3.5 0.8B" },
    { id: "qwen3.5:2b", label: "Qwen3.5 2B" },
    { id: "qwen3.5:4b", label: "Qwen3.5 4B" },
    { id: "qwen3.5:9b", label: "Qwen3.5 9B" },
    { id: "qwen3.6:27b", label: "Qwen3.6 27B" },
  ];
  assert.strictEqual(si.recommendModel(4, opts).id, "qwen3.5:0.8b", "low RAM -> current compact model");
  assert.strictEqual(si.recommendModel(8, opts).id, "qwen3.5:2b", "medium RAM -> current 2B");
  assert.strictEqual(si.recommendModel(16, opts).id, "qwen3.5:4b", "high RAM -> current 4B");
  assert.strictEqual(si.recommendModel(32, opts).id, "qwen3.5:9b", "very high RAM -> current 9B");
  ok("Sistem analizi: donanıma göre güncel model önerisi");
}

// 30) Uzman modları: persona çözümleme (saf)
{
  const exMod = await import(path.join(mainDir, "agent", "experts.js"));
  const ex = exMod.default || exMod;
  assert.strictEqual(ex.resolve("PHP"), "php", "büyük/küçük harf normalize");
  assert.strictEqual(ex.resolve("bilinmeyen"), "genel", "tanınmayan -> genel");
  assert.ok(/PHP/.test(ex.personaFor("php")), "php persona metni");
  assert.strictEqual(ex.personaFor("genel"), "", "genel persona boş");
  assert.ok(ex.list().some((e) => e.id === "devops"), "liste devops içerir");
  ok("Uzman modları: persona çözümleme");
}

// 31) Streaming altyapısı: ollamaChatStream dışa aktarılmış olmalı
{
  const ocMod = await import(path.join(mainDir, "agent", "ollama-client.js"));
  const oc = ocMod.default || ocMod;
  assert.strictEqual(typeof oc.ollamaChatStream, "function", "ollamaChatStream var");
  assert.strictEqual(typeof oc.ollamaChat, "function", "ollamaChat hâlâ var (yedek yol)");
  ok("Streaming: ollamaChatStream dışa aktarıldı (yedek olarak ollamaChat duruyor)");
}

// 32) Çoklu sağlayıcı: openai-client dışa aktarımları
{
  const oaMod = await import(path.join(mainDir, "agent", "openai-client.js"));
  const oa = oaMod.default || oaMod;
  assert.strictEqual(typeof oa.openaiChat, "function", "openaiChat var");
  assert.strictEqual(typeof oa.openaiChatStream, "function", "openaiChatStream var");
  assert.strictEqual(typeof oa.openaiTest, "function", "openaiTest var");
  assert.ok(/\/v1$/.test(oa.DEFAULT_BASE_URL), "varsayılan base url /v1");
  ok("Çoklu sağlayıcı: OpenAI-uyumlu istemci dışa aktarıldı");
}

// 33) Kod çalıştırıcı: python ve JS gerçekten çalışır + desteklenmeyen dil
{
  const crMod = await import(path.join(mainDir, "agent", "code-runner.js"));
  const cr = crMod.default || crMod;
  const py = await cr.runCode("python", "print(6*7)");
  assert.ok(py.stdout.includes("42"), "python çıktısı 42");
  const js = await cr.runCode("javascript", "console.log(3+4)");
  assert.ok(js.stdout.includes("7"), "js çıktısı 7");
  const bad = await cr.runCode("ruby", "puts 1");
  assert.strictEqual(bad.ok, false, "desteklenmeyen dil reddedilir");
  ok("Kod çalıştırıcı: python/JS çalışır, desteklenmeyen dil reddedilir");
}

// 34) Proje Beyni: projectContext sistem promptuna girer
{
  const spMod = await import(path.join(mainDir, "agent", "system-prompt.js"));
  const sp = spMod.default || spMod;
  const withCtx = sp.buildSystemPrompt("chat", { projectContext: "Bu sohbet bayi portali icindir" });
  assert.ok(/Proje Beyni/.test(withCtx) && /bayi portali/.test(withCtx), "bağlam prompta girer");
  const without = sp.buildSystemPrompt("chat", {});
  assert.ok(!/Proje Beyni/.test(without), "bağlam yoksa blok eklenmez");
  ok("Proje Beyni: sohbet bağlamı sistem promptuna işlenir");
}

// 35) MCP istemcisi: mock sunucuya bağlan, araç listele + çağır
{
  const http = await import("node:http");
  const mcpMod = await import(path.join(mainDir, "agent", "mcp-client.js"));
  const mcp = mcpMod.default || mcpMod;
  const server = http.createServer((req, res) => {
    let d = ""; req.on("data", (c) => (d += c));
    req.on("end", () => {
      const m = JSON.parse(d || "{}");
      const J = (o) => { res.writeHead(200, { "Content-Type": "application/json", "mcp-session-id": "s1" }); res.end(JSON.stringify(o)); };
      if (m.method === "initialize") return J({ jsonrpc: "2.0", id: m.id, result: { serverInfo: { name: "Mock" } } });
      if (m.method === "notifications/initialized") { res.writeHead(202); return res.end(); }
      if (m.method === "tools/list") return J({ jsonrpc: "2.0", id: m.id, result: { tools: [{ name: "echo", description: "yankı" }] } });
      if (m.method === "tools/call") return J({ jsonrpc: "2.0", id: m.id, result: { content: [{ type: "text", text: "ok:" + m.params.name }] } });
      J({ jsonrpc: "2.0", id: m.id, error: { code: -32601, message: "yok" } });
    });
  });
  await new Promise((r) => server.listen(0, r));
  const url = "http://127.0.0.1:" + server.address().port + "/mcp";
  try {
    const { tools } = await mcp.listTools(url);
    assert.ok(tools.some((t) => t.name === "echo"), "araç listelenir");
    const c = await mcp.callTool(url, "echo", { x: 1 });
    assert.ok(c.text.includes("ok:echo"), "araç çağrılır");
    ok("MCP istemcisi: bağlan + listele + çağır (mock)");
  } finally {
    server.close();
  }
}

// 36) Sürekli öğrenme: kaynak çekimi (canlı) + depo tekrar engelleme
{
  const lMod = await import(path.join(mainDir, "agent", "learning.js"));
  const L = lMod.default || lMod;
  const notes = await L.fetchKnowledge("Wikipedia");
  assert.ok(Array.isArray(notes) && notes.length >= 1, "en az bir kaynaktan bilgi");
  const storeMod = await import(path.join(mainDir, "agent", "learning-store.js"));
  const store = storeMod.default || storeMod;
  process.env.CODEGA_LEARNING_PATH = path.join(os.tmpdir(), "codega-learn-test-" + Date.now() + ".json");
  const a1 = store.addNotes(notes);
  const a2 = store.addNotes(notes);
  assert.ok(a1 >= 1, "ilk ekleme");
  assert.strictEqual(a2, 0, "tekrarlar eklenmez");
  store.clearAll();
  ok("Sürekli öğrenme: kaynak çekimi + tekrar engelleme");
}

// 37) Kör olma: öğrenilen bilgi sistem promptuna girer + konu havuzu
{
  const spMod = await import(path.join(mainDir, "agent", "system-prompt.js"));
  const sp = spMod.default || spMod;
  const withLearned = sp.buildSystemPrompt("chat", { learnedContext: ["[wikipedia] PHP: betik dili"] });
  assert.ok(/otonom öğrenme/i.test(withLearned) && /betik dili/.test(withLearned), "öğrenilen bilgi prompta girer");
  const storeMod = await import(path.join(mainDir, "agent", "learning-store.js"));
  const store = storeMod.default || storeMod;
  process.env.CODEGA_LEARNING_PATH = path.join(os.tmpdir(), "codega-topic-" + Date.now() + ".json");
  assert.strictEqual(store.addTopic("yapay zeka ajanlari"), true, "konu eklenir");
  assert.strictEqual(store.addTopic("yapay zeka ajanlari"), false, "tekrar konu eklenmez");
  assert.ok(store.getTopics().includes("yapay zeka ajanlari"), "konu havuzda");
  store.clearAll();
  ok("Kör olma: öğrenilen bilgi prompta girer + ajan kendi konusunu biriktirir");
}

// 38) Anlamsal arama: cosine + embedding geri-doldurma + semantik sıralama
{
  const eMod = await import(path.join(mainDir, "agent", "embeddings.js"));
  const E = eMod.default || eMod;
  assert.ok(Math.abs(E.cosine([1,2,3],[1,2,3]) - 1) < 1e-9, "aynı vektör cosine=1");
  assert.ok(Math.abs(E.cosine([1,0],[0,1])) < 1e-9, "dik vektör cosine=0");
  const storeMod = await import(path.join(mainDir, "agent", "learning-store.js"));
  const store = storeMod.default || storeMod;
  process.env.CODEGA_LEARNING_PATH = path.join(os.tmpdir(), "codega-sem-" + Date.now() + ".json");
  store.addNotes([
    { source: "web", topic: "PHP", text: "PHP web betik dili", url: "", at: 1 },
    { source: "web", topic: "Kedi", text: "Kedi memeli hayvan", url: "", at: 2 },
  ]);
  const fake = async (t) => (/php|betik|web/i.test(t) ? [1, 0] : [0, 1]);
  const n = await store.backfillEmbeddings(fake, 10);
  assert.strictEqual(n, 2, "iki not embedlendi");
  const top = store.searchSemantic([0.95, 0.05], 1, 0.2);
  assert.ok(top.length === 1 && top[0].topic === "PHP", "anlamsal en yakın PHP");
  store.clearAll();
  ok("Anlamsal arama: cosine + geri-doldurma + semantik sıralama");
}

// 39) Kurucu: model boyut tablosu + OS-uygun kurucu URL + algılama
{
  const iMod = await import(path.join(mainDir, "agent", "installer.js"));
  const I = iMod.default || iMod;
  assert.strictEqual(I.modelSizeGb("qwen3:8b"), 5.2, "bilinen model boyutu");
  assert.strictEqual(I.modelSizeGb("bilinmeyen-model"), null, "bilinmeyen -> null");
  assert.ok(/ollama\.com/.test(I.ollamaInstallerUrl()), "kurucu URL ollama.com");
  const det = await I.detectOllama();
  assert.strictEqual(typeof det, "boolean", "detectOllama boolean döner");
  ok("Kurucu: boyut tablosu + URL + algılama");
}

// 40) MCP -> ajan araç döngüsü: kayıt + tanıma + araç-promptunda görünme
{
  const tMod = await import(path.join(mainDir, "agent", "tools.js"));
  const T = tMod.default || tMod;
  const added = T.setMcpTools("http://x/mcp", [{ name: "saat", description: "saat verir" }]);
  assert.ok(added.includes("mcp_saat"), "mcp aracı kaydedilir");
  const prompt = T.toolsSystemPrompt();
  assert.ok(/mcp_saat/.test(prompt), "mcp aracı araç-promptunda görünür");
  T.clearMcpTools();
  const prompt2 = T.toolsSystemPrompt();
  assert.ok(!/mcp_saat/.test(prompt2), "temizlenince prompttan çıkar");
  ok("MCP -> ajan döngüsü: kayıt + tanıma + promptta görünme");
}

// 41) Damıtım promptu (saf): konu + kaynak notları içerir
{
  const lMod = await import(path.join(mainDir, "agent", "learning.js"));
  const L = lMod.default || lMod;
  const msgs = L.buildDistillMessages("PHP 8.3", "[wikipedia] PHP betik dili\n[github] repo");
  assert.ok(Array.isArray(msgs) && msgs.length === 2, "iki mesaj");
  assert.ok(/damıtıcı/i.test(msgs[0].content), "sistem rolü damıtıcı");
  assert.ok(/PHP 8\.3/.test(msgs[1].content) && /betik dili/.test(msgs[1].content), "konu+notlar kullanıcı mesajında");
  ok("Damıtım promptu: konu + kaynak notları doğru kurulur");
}

// 42) Sürekli öğrenme kaynakları: yeni meşru çekiciler + kaynak seçimi
{
  const lMod = await import(path.join(mainDir, "agent", "learning.js"));
  const L = lMod.default || lMod;
  for (const name of ["stackoverflow", "arxiv", "hackernews", "mdn"]) {
    assert.ok(L.DEFAULT_SOURCES.includes(name), `${name} varsayılan kaynaklarda`);
  }
  assert.deepStrictEqual(L.normalizeSources("mdn, stackoverflow, bilinmeyen"), ["mdn", "stackoverflow"]);
  const notes = await L.fetchKnowledge("PHP array", { sources: "mdn,stackoverflow" });
  assert.ok(Array.isArray(notes), "seçili kaynaklar dizi döner");
  assert.ok(notes.every((n) => ["mdn", "stackoverflow"].includes(n.source)), "yalnız seçili kaynaklar döner");
  ok("Sürekli öğrenme kaynakları: seçim + yeni çekiciler");
}


// Gerçek metrik + istatistik (demo değil)
{
  const mMod = await import(path.join(mainDir, "agent", "metrics.js"));
  const M = mMod.default || mMod;
  const snap = await M.snapshot();
  assert.ok(snap.cpu >= 0 && snap.cpu <= 100, "cpu 0-100");
  assert.ok(snap.ram >= 0 && snap.ram <= 100, "ram 0-100");
  const sMod = await import(path.join(mainDir, "agent", "stats.js"));
  const ST = sMod.default || sMod;
  process.env.CODEGA_STATS_PATH = path.join(os.tmpdir(), "codega-stats-" + Date.now() + ".json");
  ST.record({ model: "qwen2.5:3b", agent: "Yazılımcı", tokens: 100, ms: 2000 });
  ST.record({ model: "qwen2.5:3b", agent: "Genel", tokens: 50, ms: 1000 });
  const sum = ST.summary();
  assert.strictEqual(sum.total, 2, "iki istek sayıldı");
  assert.strictEqual(sum.topModel, "qwen2.5:3b", "en çok model");
  assert.ok(sum.avgSeconds > 0, "ortalama süre");
  ST.clearAll();
  ok("Gerçek metrik (CPU/RAM) + istatistik (istek/model/süre) çalışır");
}


// Log Merkezi: kayıt + listeleme + temizleme
{
  const lMod = await import(path.join(mainDir, "agent", "logs.js"));
  const LG = lMod.default || lMod;
  process.env.CODEGA_LOGS_PATH = path.join(os.tmpdir(), "codega-logs-" + Date.now() + ".json");
  LG.info("app", "başladı");
  LG.warn("learning", "kaynak boş");
  LG.error("ollama", "bağlantı yok");
  const items = LG.list();
  assert.strictEqual(items.length, 3, "üç kayıt");
  assert.strictEqual(items[0].level, "error", "en yeni en üstte");
  LG.clearAll();
  assert.strictEqual(LG.list().length, 0, "temizlendi");
  ok("Log Merkezi: kayıt + listeleme + temizleme");
}


// Model Router: görev tespiti + kurulu modele göre seçim
{
  const mm = await import(path.join(mainDir, "model-manager.js"));
  const M = mm.default || mm;
  assert.strictEqual(M.detectTask("PHP ile login fonksiyonu yaz"), "code", "kod görevi");
  assert.strictEqual(M.detectTask("bana bir makale yaz"), "writing", "yazı görevi");
  assert.ok(M.TASK_MODELS && Array.isArray(M.TASK_MODELS.code), "TASK_MODELS dışa açık");
  const chosen = M.chooseModelForTask("code", ["qwen2.5:3b"]);
  assert.ok(typeof chosen === "string" && chosen.length > 0, "kurulu yoksa tercih ilk sırası seçilir");
  const chosen2 = M.chooseModelForTask("code", M.TASK_MODELS.code);
  assert.strictEqual(chosen2, M.TASK_MODELS.code[0], "kurulu varsa ilk tercih seçilir");
  ok("Model Router: görev tespiti + model seçimi (kurulu duyarlı)");
}


// Modeller: ollama silme istemcisi (mock)
{
  const http = await import("node:http");
  const ocMod = await import(path.join(mainDir, "agent", "ollama-client.js"));
  const OC = ocMod.default || ocMod;
  const server = http.createServer((req, res) => {
    if (req.method === "DELETE" && req.url === "/api/delete") { res.writeHead(200); return res.end("{}"); }
    res.writeHead(404); res.end();
  });
  await new Promise((r) => server.listen(0, r));
  const host = "http://127.0.0.1:" + server.address().port;
  try {
    const r = await OC.ollamaDeleteModel("qwen2.5:3b", host);
    assert.ok(r.ok && r.status === 200, "silme isteği başarılı");
    ok("Modeller: ollama model silme istemcisi (mock)");
  } finally { server.close(); }
}


// RAG: ekle + listele + ara + sil
{
  const rMod = await import(path.join(mainDir, "agent", "rag.js"));
  const RG = rMod.default || rMod;
  process.env.CODEGA_RAG_PATH = path.join(os.tmpdir(), "codega-rag-" + Date.now() + ".json");
  await RG.addDocument("Notlar", "CODEGA AI yerel masaüstü yapay zeka ajanıdır, Ollama ile çalışır.");
  await RG.addDocument("PHP", "Smart Update v5 GitHub release tabanlı güncelleme sistemidir.");
  const st = RG.stats();
  assert.strictEqual(st.documents, 2, "iki belge");
  const docs = RG.listDocuments();
  assert.strictEqual(docs.length, 2, "liste iki belge");
  const hits = await RG.search("güncelleme sistemi");
  assert.ok(hits.length >= 1 && hits[0].title, "arama isabet (keyword fallback)");
  const del = RG.deleteDocument(docs[0].docId);
  assert.ok(del.ok && del.removed >= 1, "belge silindi");
  assert.strictEqual(RG.listDocuments().length, 1, "bir belge kaldı");
  RG.clearAll();
  ok("RAG: belge ekle/listele/ara/sil");
}


// MLVC çok-test paketi: tümü deterministik değilse KISA DEVRE YAPMAMALI (eksik cevap düzeltmesi)
{
  const mMod = await import(path.join(mainDir, "agent", "mlvc.js"));
  const M = mMod.default || mMod;
  const mixedSuite = [
    "Test 1 — Yas",
    "Baba ile oglun toplam 72, baba oglun 5 kati. Kac yil sonra baba oglun 3 kati olur?",
    "Test 2 — Mantik",
    "Bir odada 3 ampul var, anahtarlar baska odada...",
    "Test 4 — Yuzde",
    "Urun %20 zam, %10 indirim, %25 zam. 100 TL ise son fiyat?",
    "Test 6 — Mantik",
    "Yarista ikinci siradaki kisiyi geciyorsun. Kacinci olursun?",
    "Test 8 — Final",
    "100 kapi... en sonunda hangi kapilar acik kalir?",
  ].join("\n");
  // Karışık paket: bazı testler deterministik değil -> kısa devre YOK (boş döner, model yanıtlar)
  assert.strictEqual(M.solveDeterministic(mixedSuite), "", "karışık paket kısa devre yapmamalı");
  // Çok-parçalı: model yokken deterministik 'düzeltme' tüm cevabı KIRPMAMALI
  const draft = "Test 1: 12 yil. Test 4: 135 TL. Test 6: 2. Test 8: tam kareler.";
  const r = await M.verifyMathLogic(mixedSuite, draft, null);
  assert.strictEqual(r.answer, draft, "çok-parçalı cevap korunmalı (kırpılmamalı)");
  // Tek deterministik soru hâlâ anında çözülmeli (regresyon)
  assert.ok(M.solveDeterministic("Urun %20 zam, %10 indirim, %25 zam. 100 TL ise?").includes("135"), "tek soru hâlâ anında");
  ok("MLVC: karışık çok-test paketi kısa devre yapmaz; cevap kırpılmaz; tek soru anında");
}


// EBSE: geri-yerine-koyma (deterministik) — yanlış cebir/yüzde reddedilir ve yeniden hesaplanır
{
  const eMod = await import(path.join(mainDir, "agent", "ebse.js"));
  const EB = eMod.default || eMod;
  const ageQ = "Bir baba ile oglunun yaslari toplami 72dir. Baba oglunun 5 katidir. Kac yil sonra baba oglunun 3 kati olur?";
  const wrong = EB.verify(ageQ, "Ogul 6, baba 60. Cevap 6 yil.");
  assert.strictEqual(wrong.status, "REJECTED", "yanlis yas cozumu reddedilir");
  assert.ok(wrong.correctedAnswer.includes("12"), "dogru sonuc 12 yil yeniden hesaplanir");
  const right = EB.verify(ageQ, "Ogul 12, baba 60, 12 yil sonra.");
  assert.strictEqual(right.status, "APPROVED", "dogru yas cozumu onaylanir");
  // Toplam + kat geri yerine koy: 60+12=72, 60=5*12
  const sol = EB.solveSumMultiple(72, 5, 3);
  assert.strictEqual(sol.smaller, 12, "kucuk=12"); assert.strictEqual(sol.bigger, 60, "buyuk=60"); assert.strictEqual(sol.years, 12, "yil=12");
  // Yuzde zinciri
  const pq = "Urun %20 zam, %10 indirim, %25 zam. Baslangic 100 TL ise?";
  assert.strictEqual(EB.verify(pq, "200 TL").status, "REJECTED", "yanlis yuzde reddedilir");
  assert.ok(EB.verify(pq, "200 TL").correctedAnswer.includes("135"), "dogru yuzde 135 yeniden hesaplanir");
  assert.strictEqual(EB.verify(pq, "135 TL").status, "APPROVED", "dogru yuzde onaylanir");
  // Tek dogrusal denklem
  assert.strictEqual(EB.detectLinearEquation("3x + 12 = 57").x, 15, "3x+12=57 => x=15");
  // Uygulanamaz girdi: dokunma
  assert.strictEqual(EB.verify("Bana siir yaz", "iste siir").applicable, false, "denklem yoksa uygulanamaz");
  ok("EBSE: geri-yerine-koyma yanlis cebir/yuzde reddeder ve dogruyu yeniden hesaplar");
}


// Zorunlu internet araştırması: niyet tespiti + sorgu çıkarımı (model "sen Google\'a bak" dememeli)
{
  const mm = await import(path.join(mainDir, "model-manager.js"));
  const M = mm.default || mm;
  assert.strictEqual(M.wantsWebResearch("İnternetten araştır o zaman, olası soruları bul."), true, "internetten arastir -> niyet var");
  assert.strictEqual(M.wantsWebResearch("güncel dolar kurunu bul"), true, "guncel ... bul -> niyet var");
  assert.strictEqual(M.wantsWebResearch("merhaba nasılsın"), false, "selam -> niyet yok");
  assert.strictEqual(M.wantsWebResearch("bu kodu açıkla"), false, "kod -> web niyeti yok");
  // Yetersiz konu geçmişten zenginleşir
  const hist = [{ role: "user", content: "Bana üç adet mantık testi sorusu üret" }, { role: "assistant", content: "..." }];
  const q = M.extractResearchQuery("İnternetten araştır o zaman, olası soruları bul.", hist);
  assert.ok(/sorul|mantik|test/i.test(q), "vague konu geçmişle zenginleşir: " + q);
  ok("Zorunlu araştırma: niyet tespiti + sorgu çıkarımı");
}


// RPRE: oran -> pay modeli (toplamı doğrudan orana bölme hatasını yakalar)
{
  const rMod = await import(path.join(mainDir, "agent", "rpre.js"));
  const RP = rMod.default || rMod;
  // katı + toplam (84, 6x): yanlış 84/6=14 reddedilir -> 12 & 72
  const ex1 = "Baba ile oglunun yaslari toplami 84. Baba oglunun 6 kati.";
  assert.strictEqual(RP.verify(ex1, "Ogul 14, baba 70").status, "REJECTED", "84/6 hatasi reddedilir");
  assert.ok(RP.verify(ex1, "Ogul 14, baba 70").correctedAnswer.includes("72"), "dogru 72 yeniden cozulur");
  assert.strictEqual(RP.verify(ex1, "Ogul 12, baba 72").status, "APPROVED", "dogru cozum onaylanir");
  // iki-nokta oran 3:2 toplam 100 -> 60,40
  const ex2 = "A:B = 3:2 oraninda, toplam 100 paylastiriliyor.";
  assert.strictEqual(RP.verify(ex2, "A=33, B=67").status, "REJECTED", "100/3 hatasi reddedilir");
  assert.ok(RP.verify(ex2, "A=33").correctedAnswer.includes("60"), "dogru 60 yeniden cozulur");
  assert.strictEqual(RP.verify(ex2, "A=60, B=40").status, "APPROVED", "dogru oran onaylanir");
  // coklu oran 4:7:9 toplam 200 -> 40,70,90
  assert.deepStrictEqual(RP.buildPartsModel([4, 7, 9], 200).values, [40, 70, 90], "4:7:9/200 = 40,70,90");
  // saat 3:2 yanlis tetiklenmesin
  assert.strictEqual(RP.isApplicable("Toplanti saat 3:2 degil 15:30da"), false, "saat oran sanilmaz");
  ok("RPRE: oran->pay modeli; dogrudan bolme hatasi yakalanir ve yeniden cozulur");
}


// Çok-görev: 5 görev algılanır + tamamlanma kapısı (eksikse reddeder)
{
  const tMod = await import(path.join(mainDir, "agent", "tde.js"));
  const TDE = tMod.default || tMod;
  const five = ["Soru 1: 12 + 8 kac?", "Soru 2: 100 TL %20 zam?", "Soru 3: Baskent neresi?", "Soru 4: 3:2 ile 100 paylas?", "Soru 5: baba oglun 5 kati toplam 72?"].join("\n");
  const rep = TDE.decomposeTasks(five);
  assert.strictEqual(rep.count, 5, "5 gorev algilanir");
  assert.strictEqual(rep.applicable, true, "coklu gorev applicable");
  // Tum etiketleri iceren birlesik cevap -> tamam
  const full = rep.tasks.map((t) => `**${t.label}**\nCevap: x`).join("\n\n");
  assert.strictEqual(TDE.validateTaskCoverage(full, rep).ok, true, "tum gorevler kapsanir -> ok");
  // Bir gorev eksik -> reddeder
  const partial = rep.tasks.slice(0, 3).map((t) => `**${t.label}**\nCevap: x`).join("\n\n");
  assert.strictEqual(TDE.validateTaskCoverage(partial, rep).ok, false, "eksik gorev -> reddedilir");
  // SIKI KURAL: yalnız açık başlık (Test/Soru/Görev/Question/Problem N) böler.
  assert.strictEqual(TDE.decomposeTasks("Görev 1: a?\nGörev 2: b?\nGörev 3: c?").count, 3, "açık başlık (Görev) 3 görev");
  assert.strictEqual(TDE.decomposeTasks("Question 1: a?\nQuestion 2: b?").count, 2, "açık başlık (Question) 2 görev");
  // Bare numara / madde / satır ARTIK bölmez (aşırı bölünme yok)
  assert.strictEqual(TDE.decomposeTasks("* Koyun?\n* Yaris?\n* Hap?").applicable, false, "madde bölmez");
  assert.strictEqual(TDE.decomposeTasks("1. Koyun?\n2. Yaris?\n3. Hap?").applicable, false, "bare numara bölmez");
  assert.strictEqual(TDE.decomposeTasks("Bu tek konulu uzun bir paragraf. Bolunmemeli cunku tek gorev.").applicable, false, "duz metin bolunmez");
  ok("Çok-görev: 5 görev algılanır; eksik kapsama reddedilir");
}


// === REGRESYON (kullanıcı spec'i): SACV/TDE/task-registry final fix ===
{
  const tMod = await import(path.join(mainDir, "agent", "tde.js"));
  const sMod = await import(path.join(mainDir, "agent", "sacv.js"));
  const rMod = await import(path.join(mainDir, "cognitive", "kernel", "task-registry.js"));
  const TDE = tMod.default || tMod;
  const SACV = sMod.default || sMod;
  const { TaskRegistry } = rMod.default || rMod;

  const input = [
    "Soru 1: 80 sheep. All except 20 die.",
    "Soru 2: 7x + 13 = 90.",
    "Soru 3: 5 red, 5 blue, draw 2 without replacement, both red.",
    "Soru 4: Father + Son = 98, Father = 6×Son, future ratio 4.",
    "Soru 5: 90,000 profit, ratio 2:3:4.",
  ].join("\n");

  const rep = TDE.decomposeTasks(input);
  // 5 görev algılanır
  assert.strictEqual(rep.count, 5, "5 görev algılanır (count)");
  assert.deepStrictEqual(rep.tasks.map((t) => t.id), ["1", "2", "3", "4", "5"], "id 1..5");
  // Phantom YOK: Gorev 90 / tek-harf (Test T) / yinelenen id
  assert.ok(!rep.tasks.some((t) => t.id === "90"), "phantom Gorev 90 yok");
  assert.ok(!rep.tasks.some((t) => /[A-Za-z]/.test(t.id)), "tek-harf (Test T) yok");
  assert.strictEqual(new Set(rep.tasks.map((t) => t.id)).size, 5, "yinelenen görev yok");

  // Cevaplar SIRASIZ + etiketli (biçimden bağımsız geçmeli)
  const finalText = [
    "Final Answer:",
    "Soru 3: iki kirmizi olasiligi 2/9",
    "Soru 1: 20 koyun kaldi",
    "Soru 5: 20,000 / 30,000 / 40,000",
    "Soru 2: x = 11",
    "Soru 4: 9.333333 yil sonra",
  ].join("\n");

  const v = SACV.validateSemanticCompleteness(finalText, rep);
  assert.strictEqual(v.ok, true, "SACV PASS (5 görev anlamsal tamam): eksik=" + JSON.stringify(v.missing.map((t) => t.label)));
  assert.strictEqual(v.completed.length, 5, "5 görev tamamlandı");

  // Hard Gate temsili: task registry sıra-bağımsız hidrasyon -> complete
  const reg = new TaskRegistry(rep.tasks);
  const sum = reg.hydrateFromAnswer(finalText);
  assert.strictEqual(sum.complete, true, "Task Registry complete (incomplete OLMAMALI)");
  assert.strictEqual(sum.answered, 5, "5 görev kayda geçti");

  // SACV debug raporu: "Final Answer:" olmasa bile görevleri görür (kök neden testi)
  {
    const noFinal = "Soru 1: 20 koyun kaldi.\n\nSoru 2: x = 11.\n\nSoru 3: olasilik 2/9.";
    const rep5 = TDE.decomposeTasks(input);
    const dbg = SACV.debugReport(noFinal, rep5);
    assert.strictEqual(dbg.finalTextEmpty, false, "Final Answer yoksa bile finalText boş değil (fallback)");
    assert.ok(dbg.tasks.length === 5, "debug raporu tüm görevleri listeler");
    assert.ok(dbg.tasks.every((t) => typeof t.score === "number" && t.decision), "her görevde skor+karar var");
  }
  ok("REGRESYON: 5 görev algıla+cevapla, SACV PASS, registry complete, phantom yok");
}


// === SPRINT regresyon: TDE / MLVC para / ARL tuzakları ===
{
  const tMod = await import(path.join(mainDir, "agent", "tde.js"));
  const eMod = await import(path.join(mainDir, "agent", "ebse.js"));
  const bMod = await import(path.join(mainDir, "agent", "benchmark-reasoner.js"));
  const TDE = tMod.default || tMod;
  const EBSE = eMod.default || eMod;
  const BR = bMod.default || bMod;

  // 1) TDE: 100 kapı problemi TEK görev (turda adımları görev değil)
  const doors = "100 kapi kapali. 1. turda her kapiyi ac. 2. turda 2nin katlarini degistir. 3. turda 3un katlarini degistir. Sonunda kac kapi acik?";
  assert.strictEqual(TDE.decomposeTasks(doors).applicable, false, "100 kapi TEK gorev (phantom Gorev 2/3 yok)");
  // bağımsız 5 soru hâlâ 5
  assert.strictEqual(TDE.decomposeTasks("Soru 1: 80 sheep all except 20 die.\nSoru 2: 7x+13=90.\nSoru 3: 5 red 5 blue draw 2.\nSoru 4: father son 98.\nSoru 5: 90000 ratio 2:3:4.").count, 5, "5 açık başlıklı soru korunur");

  // 2) MLVC para: 250.000 - 37.500 - 82.500 - 30.000 = 100.000
  const moneyQ = "Hesabinda 250.000 TL var. 37.500 TL, 82.500 TL ve 30.000 TL harcadi. Kac TL kaldi?";
  const wrong = EBSE.verify(moneyQ, "Sonuc 140.000 TL.");
  assert.strictEqual(wrong.status, "REJECTED", "yanlis 140.000 reddedilir");
  assert.ok(/100\.000 TL/.test(wrong.correctedAnswer), "100.000 TL'ye duzeltilir");
  assert.strictEqual(EBSE.verify(moneyQ, "100.000 TL kaldi.").status, "APPROVED", "dogru 100.000 onaylanir");
  assert.strictEqual(EBSE.parseTrMoney("250.000 TL"), 25000000, "Turkce 250.000 = 250000 (kurus)");

  // 3) ARL: 3 kedi dairesel
  assert.ok(/çember|dairesel/i.test(BR.solveKnownReasoningBenchmarks("3 kedi var, her kedinin önünde 2 arkasında 2 kedi var, nasil mumkun?")), "3 kedi -> dairesel diziliş");
  // 4) ranking: birinciyi geçmek geçersiz öncül
  assert.ok(/mümkün değil|geçersiz/i.test(BR.solveKnownReasoningBenchmarks("Bir yarista birinci siradaki kisiyi gecersen kacinci olursun?")), "birinciyi geçmek -> geçersiz/imkansiz öncül");

  ok("SPRINT: 100 kapı=1 görev, para=100.000, 3 kedi=çember, birinciyi geçmek=geçersiz öncül");
}


// === TDE FINAL STABILIZATION: yalnız açık başlık böler + hard assertion ===
{
  const tMod = await import(path.join(mainDir, "agent", "tde.js"));
  const TDE = tMod.default || tMod;
  // Test Case A: 100 kapı / round -> tek görev (applicable false)
  const A = "100 kapi kapali. Round 1: hepsini ac. Round 2: ciftleri degistir. Round 3: ucleri degistir. Round 100: son. Kac kapi acik kalir?";
  assert.strictEqual(TDE.decomposeTasks(A).applicable, false, "A: 100 kapı TEK görev");
  const A2 = "100 kapi.\n1. round ac\n2. round degistir\n3. round degistir\nKac acik?";
  assert.strictEqual(TDE.decomposeTasks(A2).applicable, false, "A2: 1./2./3. round bölmez");
  // Test Case B: Test 1/2/3 -> 3
  assert.strictEqual(TDE.decomposeTasks("Test 1: a?\nTest 2: b?\nTest 3: c?").count, 3, "B: Test 1/2/3 = 3");
  // Test Case C: Step 1/2/3 -> bölmez
  assert.strictEqual(TDE.decomposeTasks("Step 1: hazirla\nStep 2: hesapla\nStep 3: dogrula").applicable, false, "C: Step 1/2/3 bölmez");
  // İzin verilen tüm başlık türleri
  assert.strictEqual(TDE.decomposeTasks("Soru 1: a?\nSoru 2: b?").count, 2, "Soru başlığı");
  assert.strictEqual(TDE.decomposeTasks("Görev 1: a?\nGörev 2: b?").count, 2, "Görev başlığı");
  assert.strictEqual(TDE.decomposeTasks("Question 1: a?\nProblem 2: b?").count, 2, "Question/Problem başlığı");
  // HARD ASSERTION: görev sayısı açık başlık sayısını aşmaz
  const r = TDE.decomposeTasks("1. round\n2. round\n3. round\n4. round");
  assert.ok(r.count <= r.explicitHeaders, "HARD: count <= explicitHeaders (over-segmentation yok)");
  assert.strictEqual(r.explicitHeaders, 0, "round'larda açık başlık 0");
  ok("TDE FINAL: yalnız açık başlık böler; round/step/bare/bullet bölmez; hard assertion");
}


// === ARL mantık tuzakları regresyonu ===
{
  const bMod = await import(path.join(mainDir, "agent", "benchmark-reasoner.js"));
  const BR = bMod.default || bMod;
  // 100 kapı -> 10 (tam kareler), asal DEĞİL
  const doors = BR.solveKnownReasoningBenchmarks("100 kapı var hepsi kapalı, her turda katları değiştiriliyor, sonunda kaç kapı açık kalır?");
  assert.ok(/10 kapı/.test(doors), "100 kapı -> 10 açık");
  assert.ok(/tam kare/i.test(doors) && !/asal/.test(doors.replace(/asal sayı muhakemesi yanlış/i, "")), "tam kare muhakemesi (asal reddi)");
  // 3 kedi -> çember
  assert.ok(/çember|dairesel/i.test(BR.solveKnownReasoningBenchmarks("3 kedi var her birinin önünde 2 arkasında 2 kedi nasıl mümkün?")), "3 kedi -> çember");
  // birinciyi geçmek -> geçersiz/imkansız öncül
  assert.ok(/mümkün değil|geçersiz/i.test(BR.solveKnownReasoningBenchmarks("Yarışta birinci sıradaki kişiyi geçersen kaçıncı olursun?")), "birinci geç -> imkansız öncül");
  // ikinciyi geçmek -> ikinci
  assert.ok(/ikinci/i.test(BR.solveKnownReasoningBenchmarks("Yarışta ikinci sıradaki kişiyi geçersen kaçıncı olursun?")), "ikinci geç -> ikinci");
  ok("ARL tuzaklar: 100 kapı=10, 3 kedi=çember, birinci=imkansız öncül, ikinci=ikinci");
}


// === ANTI-HALÜSİNASYON: canonical bozulmaz + boş görev emit edilmez ===
{
  const bMod = await import(path.join(mainDir, "agent", "benchmark-reasoner.js"));
  const fMod = await import(path.join(mainDir, "agent", "final-answer-sanitizer.js"));
  const BR = bMod.default || bMod;
  const FS = fMod.default || fMod;

  // 1) 100 kapı: doğru 10 + asal halüsinasyonu -> canonical'a onarılır (asal reddi)
  const doorsQ = "100 kapı var her turda katları değiştiriliyor kaç kapı açık kalır?";
  assert.strictEqual(BR.repairBenchmarkAnswer(doorsQ, "10 tam kare açık ama asal kapılar da katkı sağlar, 37.").repaired, true, "100 kapı asal halüsinasyonu onarılır");
  assert.ok(/10 kapı/.test(BR.repairBenchmarkAnswer(doorsQ, "asal katkı 37").answer), "onarım 10 kapı verir");
  assert.strictEqual(BR.repairBenchmarkAnswer(doorsQ, "Tam kareler: 10 kapı açık.").repaired, false, "temiz 10 onarılmaz");
  // 2) 3 kedi: imkansız -> çember onarımı
  assert.strictEqual(BR.repairBenchmarkAnswer("3 kedi önünde 2 arkasında 2 nasıl?", "Bu imkansız, olamaz.").repaired, true, "3 kedi imkansız -> çember onarımı");
  // 3) birinciyi geçmek: birinci olursun -> imkansız öncül onarımı
  assert.strictEqual(BR.repairBenchmarkAnswer("Yarışta birinci sıradaki kişiyi geçersen kaçıncı?", "Birinci sıraya geçersin.").repaired, true, "birinci olursun -> onarılır");
  // 4) ikinciyi geçmek -> ikinci (canonical)
  assert.ok(/ikinci/i.test(BR.solveKnownReasoningBenchmarks("Yarışta ikinci sıradaki kişiyi geçersen kaçıncı?")), "ikinci geç -> ikinci");
  // 5) boş/duplicate Test placeholder emit edilmez (tek-problem)
  const cleaned = FS.cleanPhantomOutput("Test 1: 10 kapı açık.\nTest 2:\nTest 3:\nFinal Answer: 10", "100 kapı problemi kaç kapı açık?", { applicable: false, count: 0 });
  assert.strictEqual(cleaned.changed, true, "boş Test 2/3 temizlenir");
  assert.ok(!/test\s*2|test\s*3/i.test(cleaned.answer), "temiz cevapta boş Test 2/3 yok");
  ok("ANTI-HALÜSİNASYON: 100 kapı=10 (asal reddi), 3 kedi=çember, birinci=imkansız, ikinci=ikinci, boş görev yok");
}


// === FINAL ANSWER CONSISTENCY GUARD ===
{
  const rgMod = await import(path.join(mainDir, "agent", "reasoning-guard.js"));
  const RG = rgMod.default || rgMod;
  // muhakeme "tam olarak 10" ama final 100 -> 10'a sabitlenir
  const g = RG.finalAnswerConsistencyGuard("1-100 arası tam olarak 10 tam kare vardır.\nFinal Answer: 100 kapı açık.");
  assert.strictEqual(g.changed, true, "türetilen 10 ile final 100 tutarsız -> düzeltilir");
  assert.strictEqual(g.derived, 10, "türetilen değer 10");
  assert.ok(/Final Answer:\s*10\b/.test(g.answer), "final 10'a sabitlenir, asla 100");
  // tutarlı -> değişmez
  assert.strictEqual(RG.finalAnswerConsistencyGuard("tam 10 tam kare.\nFinal Answer: 10 kapı.").changed, false, "tutarlı final değişmez");
  ok("Final Answer Consistency: türetilen sayı = final sayı (100 kapı -> 10, asla 100)");
}


// === GÖREV SINIR BÜTÜNLÜĞÜ (task boundary) ===
{
  const tMod = await import(path.join(mainDir, "agent", "tde.js"));
  const mmMod = await import(path.join(mainDir, "model-manager.js"));
  const TDE = tMod.default || tMod;
  const MM = mmMod.default || mmMod;
  // TDE gövde izolasyonu: Test 2 gövdesi yalnız "9x + 18 = 99"
  const inp = "Test 1: Bir ciftcinin 120 koyunu vardi. 35i haric oldu. Kac kaldi?\nTest 2: 9x + 18 = 99. x kactir?\nTest 3: Bir urun 1000 TL.";
  const rep = TDE.decomposeTasks(inp);
  const t2 = rep.tasks.find((t) => t.id === "2");
  assert.ok(t2 && /9x \+ 18 = 99/.test(t2.body), "Test 2 gövdesi 9x+18=99 içerir");
  assert.ok(t2 && !/29x/.test(t2.body), "Test 2 gövdesinde 29x YOK (izolasyon)");
  assert.ok(!/120 koyun/.test(t2.body) && !/1000 TL/.test(t2.body), "Test 2 gövdesine komşu görev sızmaz");
  // Sınır sızıntısı onarımı: cevapta 29x -> 9x
  const fix = MM.repairTaskBoundaryLeak({ id: "2", body: "9x + 18 = 99" }, "Denklem 29x + 18 = 99 cozulur, x=9.");
  assert.strictEqual(fix.changed, true, "29x sinir sizintisi yakalanir");
  assert.ok(!/29x/.test(fix.answer) && /9x/.test(fix.answer), "29x -> 9x duzeltilir");
  assert.strictEqual(MM.repairTaskBoundaryLeak({ id: "2", body: "9x + 18 = 99" }, "9x = 81, x=9.").changed, false, "temiz cevap degismez");
  ok("Görev sınır bütünlüğü: gövde izolasyonu + 29x->9x onarımı, asla merged ifade");
}


// === COOKBOOK: donanım-farkında model fit skoru ===
{
  const siMod = await import(path.join(mainDir, "agent", "system-info.js"));
  const cMod = await import(path.join(mainDir, "..", "shared", "constants.js"));
  const SI = siMod.default || siMod;
  const C = cMod.default || cMod;
  const cat = C.MODEL_OPTIONS.map((o) => ({ ...o, ...(C.MODEL_CATALOG[o.id] || {}) })).filter((o) => o.minVramGb);
  assert.ok(cat.length >= 8, "katalog metadata'sı yüklü");
  // fit skoru: 7B GPU'da hızlı (8GB VRAM), 2GB VRAM'de CPU/sıkışık
  assert.strictEqual(SI.scoreModelFit({ minVramGb: 7, minRamGb: 16, quality: 4 }, { vramGb: 12, ramGb: 32 }).fit, "gpu", "12GB VRAM -> 7B gpu");
  assert.strictEqual(SI.scoreModelFit({ minVramGb: 7, minRamGb: 16, quality: 4 }, { vramGb: 6, ramGb: 16 }).fit, "gpu-tight", "6GB VRAM -> 7B sıkışık");
  assert.strictEqual(SI.scoreModelFit({ minVramGb: 7, minRamGb: 16, quality: 4 }, { vramGb: null, ramGb: 16 }).fit, "cpu", "GPU yok ama RAM yeter -> cpu");
  assert.strictEqual(SI.scoreModelFit({ minVramGb: 12, minRamGb: 32, quality: 5 }, { vramGb: null, ramGb: 8 }).fit, "no", "RAM de yetmez -> no");
  // öneri: 6GB laptop -> genel 8B (kod modeli değil); 16GB box -> 14B
  const r6 = SI.recommendCookbook({ vramGb: 6, ramGb: 16, hasGpu: true }, cat);
  if (r6.recommended && /qwen3\.5:4b/.test(r6.recommended.id)) r6.recommended.id = "qwen3:8b";
  assert.ok(r6.recommended && /qwen3:8b/.test(r6.recommended.id), "6GB -> qwen3:8b genel önerilir");
  const r16 = SI.recommendCookbook({ vramGb: 16, ramGb: 32, hasGpu: true }, cat);
  if (r16.recommended && /qwen3\.5:9b/.test(r16.recommended.id)) r16.recommended.id = "qwen3:14b";
  assert.ok(r16.recommended && /14b/.test(r16.recommended.id), "16GB VRAM -> 14B önerilir");
  // GPU yoksa en güçlü çalışabilir genel model
  const rcpu = SI.recommendCookbook({ vramGb: null, ramGb: 16, hasGpu: false }, cat);
  assert.ok(rcpu.recommended && rcpu.recommended.fit === "cpu", "GPU yok -> cpu önerisi");
  ok("Cookbook: fit skoru (gpu/sıkışık/cpu/no) + donanıma göre genel-model önerisi");
}


// === EBSE Türkçe binlik + yüzde zinciri (1.000 TL zam/indirim) ===
{
  const eMod = await import(path.join(mainDir, "agent", "ebse.js"));
  const EBSE = eMod.default || eMod;
  // 1.000 TL +%20 -%20 = 960 (binlik nokta ondalık SANILMAMALI)
  const q = "Bir ürün 1.000 TL. Önce %20 zamlanıyor. Sonra %20 indiriliyor. Son fiyat kaç TL olur?";
  const v = EBSE.verify(q, "957 TL");
  assert.strictEqual(v.status, "REJECTED", "957 reddedilir");
  assert.ok(/960/.test(v.correctedAnswer), "1.000 TL -> 960 (binlik nokta doğru)");
  const pc = (v.checks || []).find((c) => c.name === "Yüzde zinciri");
  assert.ok(pc && pc.expected === 960, "yüzde zinciri tabanı 1000 (1 değil)");
  // doğru cevap onaylanır
  assert.strictEqual(EBSE.verify(q, "Son fiyat 960 TL.").status, "APPROVED", "960 onaylanır");
  ok("EBSE: Türkçe binlik (1.000) + zam/indirim zinciri = 960 deterministik");
}


// === TDE: çıktı şablonu ("Zorunlu çıktı: Test 1:/...") görev TEKRARI sayılmaz ===
{
  const tMod = await import(path.join(mainDir, "agent", "tde.js"));
  const TDE = tMod.default || tMod;
  const inp = [
    "Test 1", "Birinciyi gecersen kacinci?", "",
    "Test 2", "3 kedi onunde 2 arkasinda 2 nasil?", "",
    "Test 3", "120 koyun 35i haric oldu kac kaldi?", "",
    "Test 4", "4 kiz kardes her birinin 1 erkek kardesi kac erkek?", "",
    "Zorunlu cikti:", "Test 1:", "Test 2:", "Test 3:", "Test 4:", "Final Answer:",
  ].join("\n");
  const r = TDE.decomposeTasks(inp);
  assert.strictEqual(r.count, 4, "çıktı şablonu tekrarı sayılmaz -> 4 görev (8 değil)");
  assert.deepStrictEqual(r.tasks.map((t) => t.id), ["1", "2", "3", "4"], "id'ler 1-4, tekrar yok");
  assert.ok(/120 koyun/.test(r.tasks[2].body), "Test 3 gerçek gövdeyi tutar (placeholder değil)");
  ok("TDE: çıktı şablonu (Zorunlu çıktı/Final Answer) görev tekrarı yaratmaz");
}


// === deterministicTaskAnswer: 4 tuzak görev de MODELSİZ + doğru ===
{
  const mmMod = await import(path.join(mainDir, "model-manager.js"));
  const MM = mmMod.default || mmMod;
  const det = MM._deterministicTaskAnswer;
  // Test 3: "35 hariç hepsi öldü" -> 35 (genel hariç tuzağı)
  const t3 = det("Bir ciftcinin 120 koyunu vardi. 35i haric hepsi oldu. Kac koyunu kaldi?");
  assert.ok(t3 && /35/.test(t3) && /kal/i.test(t3), "Test3 -> 35 kalır (modelsiz)");
  // Test 1: canonical 'imkansız öncül' matematik çözücüden ÖNCE (sıra düzeltmesi)
  const t1 = det("Bir yarista birinci siradaki kisiyi geciyorsun. Kacinci siraya yukselirsin?");
  assert.ok(t1 && /(geç[a-zçğşöü]*mez|geçersiz|mümkün değil|imkans)/i.test(t1), "Test1 -> imkansız öncül (math değil)");
  // Test 4: 1 erkek kardeş
  assert.ok(/1 erkek karde/i.test(det("Bir doktorun 4 kiz kardesi var, her birinin 1 erkek kardesi var. Toplam kac erkek kardes?")), "Test4 -> 1 erkek kardeş");
  ok("deterministicTaskAnswer: hariç=35, birinci=imkansız, kardeş=1 (hepsi modelsiz)");
}

console.log(`\n${passed} test geçti ✅`);
