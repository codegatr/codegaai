from pathlib import Path
import re
import unittest


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "apps" / "codegaai-desktop"


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


class CodegaAiDesktopCleanStartTests(unittest.TestCase):
    def test_windows_desktop_app_is_isolated_from_legacy_python_stack(self):
        package = read("apps/codegaai-desktop/package.json")
        workflow = read(".github/workflows/build-codegaai-desktop-windows.yml")

        self.assertIn('"productName": "CODEGA AI"', package)
        self.assertIn('"electron-updater"', package)
        self.assertIn('"nsis"', package)
        self.assertIn("Build CODEGA AI Windows installer", workflow)
        self.assertIn("apps/codegaai-desktop", workflow)
        # Sürüm build workflow'unda `npm version` ile bumplanıyor; sabit bir sürüme
        # bağlanmak her release'te testi kırar. Geçerli semver olması yeterli.
        self.assertRegex(package, r'"version":\s*"\d+\.\d+\.\d+"')
        self.assertNotIn('"publisherName": "CODEGA"', package)
        self.assertIn("workflow_dispatch:", workflow)
        self.assertIn("npm version $version --no-git-tag-version --allow-same-version", workflow)
        self.assertIn("release/latest.yml", workflow)
        self.assertIn("tag=desktop-v$version", workflow)
        self.assertIn("github.ref == 'refs/heads/main'", workflow)

    def test_update_flow_can_close_and_install_running_app(self):
        updater = read("apps/codegaai-desktop/src/main/update-service.js")
        renderer = read("apps/codegaai-desktop/src/renderer/renderer.js")

        self.assertIn("autoUpdater.autoDownload = false", updater)
        self.assertIn("autoUpdater.verifyUpdateCodeSignature = false", updater)
        self.assertIn("autoUpdater.quitAndInstall(false, true)", updater)
        self.assertIn("!app.isPackaged", updater)
        self.assertIn("updates:status", updater)
        self.assertNotIn("setTimeout(() => this.check(), 3500)", updater)
        self.assertIn("imzasız installer", updater)
        self.assertIn("Güncelleme kontrol edilemedi", renderer)
        self.assertIn("Güncelleme hatası", renderer)
        self.assertIn("Güncelleme indirildi", renderer)
        self.assertIn("checkUpdatesAfterFirstQuery", renderer)
        self.assertIn("showUpdatePrompt(\"available\"", renderer)
        self.assertIn("showUpdatePrompt(\"ready\"", renderer)

    def test_update_prompt_asks_now_or_later(self):
        html = read("apps/codegaai-desktop/src/renderer/index.html")
        css = read("apps/codegaai-desktop/src/renderer/styles.css")

        self.assertIn('id="update-prompt"', html)
        self.assertIn("Şimdi Güncelle", html)
        self.assertIn("Daha Sonra", html)
        self.assertIn(".update-prompt", css)

    def test_ai_layer_has_instant_and_ollama_providers(self):
        model_manager = read("apps/codegaai-desktop/src/main/model-manager.js")
        constants = read("apps/codegaai-desktop/src/shared/constants.js")
        main = read("apps/codegaai-desktop/src/main/main.js")
        renderer = read("apps/codegaai-desktop/src/renderer/renderer.js")

        self.assertIn("function instantAnswer", model_manager)
        self.assertIn("ollama", model_manager)
        self.assertIn("qwen2.5-coder:3b-instruct", constants)
        self.assertIn("qwen2.5:3b", constants)
        self.assertIn("https://ollama.com/download/windows", constants)
        self.assertIn("OLLAMA_COMMAND_TIMEOUT_MS", constants)
        self.assertIn("const OLLAMA_CHAT_TIMEOUT_MS = 90 * 1000", constants)
        self.assertIn("MODEL_OPTIONS", constants)
        self.assertIn("qwen3:8b", constants)
        self.assertIn("LOCALAPPDATA", model_manager)
        self.assertIn("ollamaCandidates", model_manager)
        self.assertIn("modelCandidates", model_manager)
        self.assertIn("detectTask", model_manager)
        self.assertIn("TASK_MODELS", model_manager)
        self.assertIn("candidateModelsForTask", model_manager)
        # generate() en fazla 3 yedek modeli dener (eski sürümde 4'tü).
        self.assertIn(".slice(0, 3)", model_manager)
        self.assertIn("qwen2.5-coder:7b-instruct", model_manager)
        self.assertIn("qwen2.5-coder:3b-instruct", model_manager)
        self.assertIn("runOllama", model_manager)
        self.assertIn("child.kill()", model_manager)
        self.assertIn("timedOut", model_manager)
        # Zaman aşımı artık runCommand içinde timedOut + zaman aşımı mesajıyla,
        # üretim hatası ise codega-error zarif düşüşüyle ele alınıyor.
        self.assertIn("zaman aşımına uğradı", model_manager)
        self.assertIn('"codega-error"', model_manager)
        self.assertIn('action: "install_ollama"', model_manager)
        self.assertIn("shell.openExternal(status.actionUrl)", main)
        self.assertIn('ipcMain.handle("models:list"', main)
        self.assertIn("prepareModel(modelId", main)
        self.assertIn("prepareDefaultModel", model_manager)
        self.assertIn("els.prepareModel.disabled = true", renderer)
        self.assertIn("window.codega.getModels", renderer)
        self.assertIn("data-model", renderer)
        self.assertIn("Düşünüyorum...", renderer)
        self.assertNotIn("Uygun model seçiliyor", renderer)
        self.assertNotIn("Kullanılan model:", model_manager)
        self.assertNotIn("Ayarlar'dan daha küçük/hızlı zeka paketini indirirsen", model_manager)
        self.assertIn("scrollConversationToBottom", renderer)
        self.assertIn("scrollIntoView", renderer)
        self.assertIn("window.codega.sendMessage", renderer)
        self.assertIn('event.key === "Enter"', renderer)
        # Enter artık requestSubmit yerine doğrudan handleSubmit() çağırıyor
        # (tüm platformlarda — Mac dahil — güvenilir çalışsın diye).
        self.assertIn("handleSubmit()", renderer)

    def test_minimal_ui_keeps_history_settings_and_prompt(self):
        html = read("apps/codegaai-desktop/src/renderer/index.html")
        css = read("apps/codegaai-desktop/src/renderer/styles.css")

        self.assertIn("Sohbetler", html)
        self.assertIn("settings-button", html)
        self.assertIn("Ne yapmak istiyorsun?", html)
        self.assertIn("grid-template-columns: 286px 1fr", css)
        self.assertIn("border-radius: 999px", css)

    def test_desktop_history_can_share_delete_persist_and_export_zip(self):
        renderer = read("apps/codegaai-desktop/src/renderer/renderer.js")
        css = read("apps/codegaai-desktop/src/renderer/styles.css")

        self.assertIn("STORAGE_KEY", renderer)
        self.assertIn("localStorage.setItem", renderer)
        self.assertIn("loadChats", renderer)
        self.assertIn("shareChat", renderer)
        self.assertIn("buildShareLink", renderer)
        self.assertIn("#share=", renderer)
        self.assertIn("navigator.clipboard.writeText", renderer)
        self.assertIn("window.codega.shareChat", renderer)
        self.assertIn("deleteChat", renderer)
        self.assertIn("window.confirm", renderer)
        self.assertIn("downloadChatZip", renderer)
        self.assertIn("buildZip", renderer)
        self.assertIn("chat.json", renderer)
        self.assertIn("chat.md", renderer)
        self.assertIn(".history-entry", css)
        self.assertIn(".history-actions", css)

    def test_desktop_share_uses_codega_federation_service(self):
        constants = read("apps/codegaai-desktop/src/shared/constants.js")
        main = read("apps/codegaai-desktop/src/main/main.js")
        preload = read("apps/codegaai-desktop/src/main/preload.js")

        self.assertIn("FEDERATION_BASE_URL", constants)
        self.assertIn("https://ai.codega.com.tr/api/federation", constants)
        self.assertIn('ipcMain.handle("chat:share"', main)
        # Koddaki bilinçli düzeltme: sondaki "/" 301 redirect'in POST'u GET'e
        # çevirmesini önlüyor (main.js'deki açıklamaya bakın).
        self.assertIn('`${FEDERATION_BASE_URL}/share/`', main)
        self.assertIn("shareChat", preload)


if __name__ == "__main__":
    unittest.main()
